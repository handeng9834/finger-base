#ifndef  __MYMCU_I2C_H
#define  __MYMCU_I2C_H

//----------------------------------Include------------------------------------
#include "my_type_rdf.h"
#include "stm32l0xx_ll_gpio.h"
#include "stm32l0xx_ll_bus.h"
#include "stm32l0xx_ll_rcc.h"
#include "my_glbvar.h"
//-----------------------------------------------------------------------------

// ��I2C�ӿڶ���
#if My_DBG

	#define I2Cx_INSTANCE               	I2C1
	#define I2Cx_CLK_ENABLE()           	LL_IOP_GRP1_EnableClock(LL_IOP_GRP1_PERIPH_GPIOA)
	#define I2Cx_SCL_PIN                 	LL_GPIO_PIN_9
	#define I2Cx_SCL_GPIO_PORT           	GPIOA
	#define I2Cx_SET_SCL_GPIO_AF()       	LL_GPIO_SetAFPin_8_15(GPIOA, LL_GPIO_PIN_9, LL_GPIO_AF_1)				

	#define I2Cx_SDA_PIN                 	LL_GPIO_PIN_10
	#define I2Cx_SDA_GPIO_PORT           	GPIOA
	#define I2Cx_SET_SDA_GPIO_AF()       	LL_GPIO_SetAFPin_8_15(GPIOA, LL_GPIO_PIN_10, LL_GPIO_AF_1)


#else

	#define I2Cx_INSTANCE               	I2C1
	#define I2Cx_CLK_ENABLE()           	LL_IOP_GRP1_EnableClock(LL_IOP_GRP1_PERIPH_GPIOB);
	#define I2Cx_SCL_PIN                 	LL_GPIO_PIN_6
	#define I2Cx_SCL_GPIO_PORT           	GPIOB
	#define I2Cx_SET_SCL_GPIO_AF()       	LL_GPIO_SetAFPin_0_7(GPIOB, LL_GPIO_PIN_6, LL_GPIO_AF_1)				

	#define I2Cx_SDA_PIN                 	LL_GPIO_PIN_7	
	#define I2Cx_SDA_GPIO_PORT           	GPIOB
	#define I2Cx_SET_SDA_GPIO_AF()       	LL_GPIO_SetAFPin_0_7(GPIOB, LL_GPIO_PIN_7, LL_GPIO_AF_1)

#endif


// ��I2C�ӿڶ���

#define GPIO_I2C_WR	0		/* д����bit */
#define GPIO_I2C_RD	1		/* ������bit */


/* ����I2C�������ӵ�GPIO�˿�, �û�ֻ��Ҫ�޸�����4�д��뼴������ı�SCL��SDA������ */

#define GPIO_PORT_I2CSCL	GPIOA												/* GPIO�˿� */
#define GPIO_RCC_I2CSCL_PORT 	RCC_APB2Periph_GPIOA		/* GPIO�˿�ʱ�� */
#define GPIO_PORT_I2CSDA	GPIOA												/* GPIO�˿� */
#define GPIO_RCC_I2CSDA_PORT 	RCC_APB2Periph_GPIOA		/* GPIO�˿�ʱ�� */

#define GPIO_I2C_SCL_PIN		LL_GPIO_PIN_9							/* ���ӵ�SCLʱ���ߵ�GPIO */	
#define GPIO_I2C_SDA_PIN		LL_GPIO_PIN_10						/* ���ӵ�SDA�����ߵ�GPIO */


/* �����дSCL��SDA�ĺ꣬�����Ӵ���Ŀ���ֲ�ԺͿ��Ķ��� */

#define GPIO_I2C_SCL_1()  	 LL_GPIO_SetOutputPin(GPIO_PORT_I2CSCL, GPIO_I2C_SCL_PIN)			/* SCL = 1 */		
#define GPIO_I2C_SCL_0()  	 LL_GPIO_ResetOutputPin(GPIO_PORT_I2CSCL, GPIO_I2C_SCL_PIN)		/* SCL = 0 */
	
#define GPIO_I2C_SDA_1()  	 LL_GPIO_SetOutputPin(GPIO_PORT_I2CSDA, GPIO_I2C_SDA_PIN)			/* SDA = 1 */
#define GPIO_I2C_SDA_0()  	 LL_GPIO_ResetOutputPin(GPIO_PORT_I2CSDA, GPIO_I2C_SDA_PIN)		/* SDA = 0 */
	
#define GPIO_I2C_SDA_READ()  LL_GPIO_IsInputPinSet(GPIO_PORT_I2CSDA, GPIO_I2C_SDA_PIN)		/* ��SDA����״̬ */


#define SLAVE_ICM20602_Addr							(0x69 << 1)
#define SLAVE_ICM20602_ID_REG						0x75					//Device ID = 0x12
// ����ICM-20602��I2C��ַ��SA0=1ʱΪ0x69
#define ICM20602_ADDR 0x69
#define delta_T     0.001f  // ��������1ms��Ƶ��1kHz
#define PI          3.1415926f
#define WHO_AM_I_ID 0x12    // �豸ID
#define I2C_WRITE   0
#define I2C_READ    1
#define RAD_TO_DEG  (180.0f/PI)
// �Ĵ�����ַ����
#define PWR_MGMT_1               0x6B
#define GYRO_CONFIG              0x1B
#define ACCEL_CONFIG             0x1C
#define SMPLRT_DIV               0x19
#define CONFIG                   0x1A
#define ACCEL_XOUT_H             0x3B
#define GYRO_XOUT_H              0x43
#define WHO_AM_I                 0x75   // <-- WHO_AM_I �����ڴ˴�



#define EEPROM_DEV_ADDR			0xA0		/* 24xx02���豸��ַ */
#define EEPROM_PAGE_SIZE		  8			  /* 24xx02��ҳ���С */
#define EEPROM_SIZE				  256			  /* 24xx02������ */


//----------------------------------Declare------------------------------------
void Slave_Ready_To_Transmit_Callback(void);
void Slave_Reception_Callback(void);
void Slave_Complete_Callback(void);
void Error_Callback(void);
void I2C1_Slave_Init(void);
extern uint8_t g_i2c_send_buffer[];
extern __IO uint8_t ubSlaveTransmitIndex;
//uint32_t read_i2c_OAR1reg(void);
//void Set_I2C1_Ram(uint8_t adr, uint8_t val) ;
//void I2C1_Ram_Init(void) ;


void i2c_Start(void);
void i2c_Stop(void);
void i2c_SendByte(uint8_t _ucByte);
uint8_t i2c_ReadByte(void);
uint8_t i2c_WaitAck(void);
void i2c_Ack(void);
void i2c_NAck(void);
uint8_t i2c_CheckDevice(uint8_t _Address);

uint8_t i2c_ReadBytes(uint8_t *_pReadBuf, uint16_t devieceaddr,uint16_t _usAddress, uint16_t _usSize);
uint8_t i2c_WriteBytes(uint8_t *_pWriteBuf,  uint16_t devieceaddr,uint16_t _usAddress, uint16_t _usSize);
uint8_t i2c_WriteWord(uint16_t _pWriteWord, uint16_t devieceaddr,uint16_t _usAddress);
uint8_t i2c_WriteControlREG_TCA9545(uint8_t WriteData, uint16_t devieceaddr);
float MyMcu_Get_temp(int8_t temp_H,int8_t temp_L);

//-----------------------------------------------------------------------------

#endif
//------------------------------------EOF--------------------------------------



