//----------------------------------Include------------------------------------
#include "my_type_rdf.h"
#include "my_glbvar.h"
#include "my_mcu.h"
//-----------------------------------------------------------------------------

//-----------------------------------Macro-------------------------------------
//-----------------------------------------------------------------------------

//------------------------------------Type-------------------------------------
//-----------------------------------------------------------------------------

//-----------------------------------Const-------------------------------------
//-----------------------------------------------------------------------------

//---------------------------------Static Var----------------------------------
//-----------------------------------------------------------------------------

//--------------------------------Static Func----------------------------------
//-----------------------------------------------------------------------------

//--------------------------------Public Func----------------------------------

/**
  * @brief  Configures EXTI Line8 and Line15 (connected to PA8 and PA15 pin) in interrupt mode.
  * @param  None
  * @retval None
  */
void MyMcu_Init_EXTI(void)
{
  LL_EXTI_InitTypeDef LL_EXTI_StructInit;
	
	/* Enable GPIOA clock */
  LL_IOP_GRP1_EnableClock(LL_IOP_GRP1_PERIPH_GPIOA);
  
  /* Configure PA8 pin as input floating */
	LL_GPIO_SetPinMode(GPIOA, LL_GPIO_PIN_8, LL_GPIO_MODE_INPUT);
	LL_GPIO_SetPinPull(GPIOA, LL_GPIO_PIN_8, LL_GPIO_PULL_NO);
	LL_GPIO_SetPinSpeed(GPIOA, LL_GPIO_PIN_8, LL_GPIO_SPEED_FREQ_HIGH);
	
	LL_EXTI_StructInit.Line_0_31 = LL_EXTI_LINE_8;
  LL_EXTI_StructInit.LineCommand    = ENABLE;
  LL_EXTI_StructInit.Mode           = LL_EXTI_MODE_IT;
  LL_EXTI_StructInit.Trigger        = LL_EXTI_TRIGGER_FALLING;
	LL_EXTI_Init(&LL_EXTI_StructInit);
	
	  /* Configure PA15 pin as input floating */
		LL_GPIO_SetPinMode(GPIOA, LL_GPIO_PIN_15, LL_GPIO_MODE_INPUT);
	LL_GPIO_SetPinPull(GPIOA, LL_GPIO_PIN_15, LL_GPIO_PULL_NO);
	LL_GPIO_SetPinSpeed(GPIOA, LL_GPIO_PIN_15, LL_GPIO_SPEED_FREQ_HIGH);
	
	LL_EXTI_StructInit.Line_0_31 = LL_EXTI_LINE_15;
  LL_EXTI_StructInit.LineCommand    = ENABLE;
  LL_EXTI_StructInit.Mode           = LL_EXTI_MODE_IT;
  LL_EXTI_StructInit.Trigger        = LL_EXTI_TRIGGER_FALLING;
	LL_EXTI_Init(&LL_EXTI_StructInit);
	
	
  /* Enable and set EXTI4_15 Interrupt to the lowest priority */
	NVIC_SetPriority(EXTI4_15_IRQn, 1);  
  NVIC_EnableIRQ(EXTI4_15_IRQn);
}

void	EXTI4_15_IRQHandler(void)
{
	u8	_iic_temp[2] = {0};
	if(LL_EXTI_IsActiveFlag_0_31(LL_EXTI_LINE_8) == 1){
		i2c_ReadBytes(&(_iic_temp[0]), SLAVE_VCNL36825T_Addr, VCNL36825T_PS_INT_FLAG, 2); //����жϱ�־
		LL_EXTI_ClearFlag_0_31(LL_EXTI_LINE_8); // ���EXTI����λ
	}
	
}

//-----------------------------------------------------------------------------

//------------------------------------EOF--------------------------------------




