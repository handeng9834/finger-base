//----------------------------------Include------------------------------------
#include "my_type_rdf.h"
//#include "my_cfg.h"
#include "my_mcu.h"

//-----------------------------------------------------------------------------

//-----------------------------------Macro-------------------------------------
//-----------------------------------------------------------------------------

//--------------------------------Static Var-----------------------------------
//static u8   ADCPrescTable[4] = {2, 4, 6, 8};
//static u8   APBPrescTable[8] = {0, 0, 0, 0, 1, 2, 3, 4};
//static u8   AHBPrescTable[16]= {0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 6, 7, 8, 9};

//u32  nu32_CLK_AHB;
//u32  nu32_CLK_APB1;
//u32  nu32_CLK_APB2;
//u32  nu32_CLK_APB1_TIM;
//u32  nu32_CLK_APB2_TIM;
//u32  nu32_CLK_ADC;
////-----------------------------------------------------------------------------

////--------------------------------Public Func----------------------------------

/* Private typedef -----------------------------------------------------------*/
/* Structure based on parameters used for PLL config */
typedef struct
{
  uint32_t Frequency;	/*!< SYSCLK frequency requested */
  uint32_t PLLMul;	    /*!< PLL Multiplicator factor used for PLL */
  uint32_t PLLDiv;	    /*!< PLL Divider factor used for PLL */
  uint32_t Latency;	  /*!< Latency to be used with SYSCLK frequency */
} RCC_PLL_ConfigTypeDef;

/* Private define ------------------------------------------------------------*/
/* Number of PLL Config */
#define RCC_PLL_CONFIG_NB   2
#define RCC_FREQUENCY_LOW          ((uint32_t)16000000) /* Low Frequency set to 16MHz*/
#define RCC_FREQUENCY_HIGH         ((uint32_t)32000000) /* High Frequency set to 32Hz*/

/* Oscillator time-out values */
#define HSE_TIMEOUT_VALUE          ((uint32_t)5000) /* Time out for HSE start up, in ms */
#define HSI_TIMEOUT_VALUE          ((uint32_t)100)  /* 100 ms */
#define MSI_TIMEOUT_VALUE          ((uint32_t)100)  /* 100 ms */
#define PLL_TIMEOUT_VALUE          ((uint32_t)100)  /* 100 ms */
#define CLOCKSWITCH_TIMEOUT_VALUE  ((uint32_t)5000) /* 5 s    */


/**
  * @brief  System Clock Configuration
      *         The system Clock is configured as follows :
      *            System Clock source            = PLL (HSI)
      *            SYSCLK(Hz)                     = 32000000
      *            HCLK(Hz)                       = 32000000
      *            AHB Prescaler                  = 1
      *            APB1 Prescaler                 = 2
      *            APB2 Prescaler                 = 2
      *            HSI Frequency(Hz)              = 16000000
      *            PLL_MUL                        = 4
      *            PLL_DIV                        = 2
      *            Flash Latency(WS)              = 1
  * @retval None
  */
void MyMcu_SysClock(void)
{
		LL_RCC_PLL_Disable();
    /* Set new latency */
    LL_FLASH_SetLatency(LL_FLASH_LATENCY_1);
 
    /* HSI configuration and activation */
    LL_RCC_HSI_Enable();
    LL_RCC_HSI_DisableDivider();
    while(LL_RCC_HSI_IsReady() != 1) 
    {
    };
    
    /* Main PLL configuration and activation */
    LL_RCC_PLL_ConfigDomain_SYS(LL_RCC_PLLSOURCE_HSI, LL_RCC_PLL_MUL_4, LL_RCC_PLL_DIV_2);

    LL_RCC_PLL_Enable();
    while(LL_RCC_PLL_IsReady() != 1) 
    {
    };
    
    /* Sysclk activation on the main PLL */
    LL_RCC_SetAHBPrescaler(LL_RCC_SYSCLK_DIV_1);

    LL_RCC_SetSysClkSource(LL_RCC_SYS_CLKSOURCE_PLL);

    while(LL_RCC_GetSysClkSource() != LL_RCC_SYS_CLKSOURCE_STATUS_PLL)  
    {
    };
    
    /* Set APB1 & APB2 prescaler*/
    LL_RCC_SetAPB1Prescaler(LL_RCC_APB2_DIV_2);
    LL_RCC_SetAPB2Prescaler(LL_RCC_APB2_DIV_2);

    /* Set systick to 1ms in using frequency set to 32MHz */
    LL_Init1msTick(32000000);
  
    /* Update CMSIS variable (which can be updated also through SystemCoreClockUpdate function) */
    LL_SetSystemCoreClock(32000000);
}
//void MyMcu_SysClock(void)
//{
//  u32   tmp;
//  GPIO_InitTypeDef    GPIO_InitStruct;

////USE HSI 8MHz
//#if 0
//  uint32_t StartUpCounter = 0, HSIStatus = 0;
//  
//  RCC->CR |= (uint32_t)0x00000001;    //Set HSION bit
//  do{
//    HSIStatus = RCC->CR & RCC_CR_HSIRDY;
//    StartUpCounter++;  
//  }while( (HSIStatus == 0) && (StartUpCounter != 0xF0000000) );
//  
//  if( (RCC->CR & RCC_CR_HSIRDY) != RESET ){
//    HSIStatus = (uint32_t)0x01;
//  }else{
//    HSIStatus = (uint32_t)0x00;
//  }  

//  if(HSIStatus == (uint32_t)0x01){
//    //�⼸�䲻�ӵ���Ҫ�ܷ�
//    FLASH->ACR |= FLASH_ACR_PRFTBE;                          //Enable Prefetch Buffer
//    FLASH->ACR &= (uint32_t)((uint32_t)~FLASH_ACR_LATENCY);  //Flash 2 wait state
//    FLASH->ACR |= (uint32_t)FLASH_ACR_LATENCY_2;
//    
//    RCC->CFGR |= (uint32_t)RCC_CFGR_HPRE_DIV1;    //HCLK = SYSCLK
//    RCC->CFGR |= (uint32_t)RCC_CFGR_PPRE2_DIV1;   //PCLK2 = HCLK
//    RCC->CFGR |= (uint32_t)RCC_CFGR_PPRE1_DIV2;   //PCLK1 = HCLK/2
//    RCC->CFGR |= (uint32_t)RCC_CFGR_ADCPRE_DIV8;
//    
//    //PLL configuration: PLLCLK = HSI/2 * 16 = 64 MHz
//    RCC->CFGR &= (uint32_t)((uint32_t)~(RCC_CFGR_PLLSRC | RCC_CFGR_PLLXTPRE | RCC_CFGR_PLLMULL));
//    RCC->CFGR |= (uint32_t)(RCC_CFGR_PLLSRC_HSI_Div2 | RCC_CFGR_PLLMULL16);
//    RCC->CR   |= RCC_CR_PLLON;                //Enable PLL
//    while((RCC->CR & RCC_CR_PLLRDY) == 0){}   //Wait till PLL is ready
//    
//    RCC->CFGR &= (uint32_t)((uint32_t)~(RCC_CFGR_SW));  //Select PLL as system clock source
//    RCC->CFGR |= (uint32_t)RCC_CFGR_SW_PLL;    

//    //Wait till PLL is used as system clock source
//    while ((RCC->CFGR & (uint32_t)RCC_CFGR_SWS) != (uint32_t)0x08){}
//  }
//#endif

////USE HSE
//#if 1
//  uint32_t StartUpCounter = 0, HSEStatus = 0;
//  
//  RCC->CR |= ((uint32_t)RCC_CR_HSEON);    //Enable HSE
//  do{   //Wait till HSE is ready and if Time out is reached exit
//    HSEStatus = RCC->CR & RCC_CR_HSERDY;
//    StartUpCounter++;  
//  }while( (HSEStatus == 0) && (StartUpCounter != 0xF0000000) );

//  if( (RCC->CR & RCC_CR_HSERDY) != RESET ){
//    HSEStatus = (uint32_t)0x01;
//  }else{
//    HSEStatus = (uint32_t)0x00;
//  }

//  if(HSEStatus == (uint32_t)0x01){
//    //�⼸�䲻�ӵ���Ҫ�ܷ�
//    FLASH->ACR |= FLASH_ACR_PRFTBE;                          //Enable Prefetch Buffer
//    FLASH->ACR &= (uint32_t)((uint32_t)~FLASH_ACR_LATENCY);  //Flash 2 wait state
//    FLASH->ACR |= (uint32_t)FLASH_ACR_LATENCY_2;
//    
//    RCC->CFGR |= (uint32_t)RCC_CFGR_HPRE_DIV1;    //HCLK = SYSCLK
//    RCC->CFGR |= (uint32_t)RCC_CFGR_PPRE2_DIV1;   //PCLK2 = HCLK
//    RCC->CFGR |= (uint32_t)RCC_CFGR_PPRE1_DIV2;   //PCLK1 = HCLK/2
//    
//    //PLL configuration: PLLCLK = HSE * 6 -> 12*6 = 72 MHz
//    RCC->CFGR &= (uint32_t)((uint32_t)~(RCC_CFGR_PLLSRC | RCC_CFGR_PLLXTPRE | RCC_CFGR_PLLMULL));
//    RCC->CFGR |= (uint32_t)(RCC_CFGR_PLLSRC_HSE | RCC_CFGR_PLLMULL6);
//    RCC->CR   |= RCC_CR_PLLON;                //Enable PLL
//    while((RCC->CR & RCC_CR_PLLRDY) == 0){}   //Wait till PLL is ready
//    
//    RCC->CFGR &= (uint32_t)((uint32_t)~(RCC_CFGR_SW));  //Select PLL as system clock source
//    RCC->CFGR |= (uint32_t)RCC_CFGR_SW_PLL;    

//    //Wait till PLL is used as system clock source
//    while ((RCC->CFGR & (uint32_t)RCC_CFGR_SWS) != (uint32_t)0x08){}
//  }
//#endif
//  
//#if 0
//  //Ƶ�ʲ���
//  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
//  RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
//  
//  GPIO_StructInit(&GPIO_InitStruct);
//  GPIO_InitStruct.GPIO_Mode  = GPIO_Mode_AF_PP;
//  GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
//  
//  //MCO1 -- PA8
//  GPIO_InitStruct.GPIO_Pin   = GPIO_Pin_8;
//  GPIO_Init(GPIOA, &GPIO_InitStruct);
//  
//  RCC->CFGR &= ~RCC_CFGR_MCO;
//  RCC->CFGR |= 0x7<<24;  //0xx--no  100--sysclk  101--HSI  110--HSE  111--PLL/2
//#endif

//  SystemCoreClockUpdate();
//  
//  tmp = AHBPrescTable[((RCC->CFGR & RCC_CFGR_HPRE) >> 4)];
//  nu32_CLK_AHB = SystemCoreClock >> tmp;
//  
//  tmp = APBPrescTable[((RCC->CFGR & RCC_CFGR_PPRE1) >> 8)];   //APB1 ��� 36MHz
//  nu32_CLK_APB1 = nu32_CLK_AHB >> tmp;
//  if( (RCC->CFGR & RCC_CFGR_PPRE1) == RCC_CFGR_PPRE1_DIV1 ){
//    nu32_CLK_APB1_TIM = nu32_CLK_APB1;
//  }else{
//    nu32_CLK_APB1_TIM = nu32_CLK_APB1*2;
//  }
//  
//  tmp = APBPrescTable[((RCC->CFGR & RCC_CFGR_PPRE2) >> 11)];  //APB2 ��� 72MHz
//  nu32_CLK_APB2 = nu32_CLK_AHB >> tmp;
//  if( (RCC->CFGR & RCC_CFGR_PPRE2) == RCC_CFGR_PPRE2_DIV1 ){
//    nu32_CLK_APB2_TIM = nu32_CLK_APB2;
//  }else{
//    nu32_CLK_APB2_TIM = nu32_CLK_APB2*2;
//  }
//  
//  tmp = ADCPrescTable[((RCC->CFGR & RCC_CFGR_ADCPRE) >> 14)]; //ADCCLK ��� 14MHz
//  nu32_CLK_ADC = nu32_CLK_APB2 / tmp;
//}

////�������ȼ�����
////�����mcu��4λ�������ȼ�����ô���������Ч
////SCB->AIRCR[10:8]   ��ռ���ȼ�λ��   �����ȼ�λ��
////    3                  [7:4]            x
////    4                  [7:5]           [4]
////    5                  [7:6]           [5:4]
////    6                  [7:7]           [6:4]
////    7                    x             [7:4]
////�˺�����ͬ�ڵ��ÿ⺯��  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
////�����ø��ж����ȼ�֮ǰ��������ô˺��������÷��飬�������ȼ�����Ҳ��Ч
//void MyMcu_PriGrpCfg(void)
//{ 
//  u32   i,k;
//  u8    c;
//  
////ȷ����mcu�ö���λ�������ȼ�
//  NVIC->IP[0] = 0xFF;
//  c = NVIC->IP[0];
//  NVIC->IP[0] = 0x00;
//  for(i=0,k=0; i<8; i++){
//    if( (c>>i)&0x1 ) k++;
//  }
////��ʱ�ɵ�֪��mcu��kλ�������ȼ�
//  //LPC1788   -- 5 λ�������ȼ�
//  //STM32F4XX -- 4
//  
//  i  = SCB->AIRCR;            //��ȡ
//  i &= (7<<8);                //�����ǰ����
//  i |= (0x05FA0000|(5<<8));   //2��ռ��2�����ȣ�����д����Կ��
//  
//  SCB->AIRCR = i;
//}

//void MyMcu_Int_Disable(void)     { __asm{CPSID  I} }
//void MyMcu_Int_Enable(void)      { __asm{CPSIE  I} }
//void MyMcu_Nop(void)             { __asm{nop} }
//void MyMcu_Reset(void)           { SCB->AIRCR = 0X05FA0000|(1<<2); }
//                                 
//u32  MyMcu_GetSysClk(void)       { return SystemCoreClock; }
//u32  MyMcu_GetClk_AHB(void)      { return nu32_CLK_AHB; }
//u32  MyMcu_GetClk_ADC(void)
//{
//  u32   tmp;
//  tmp = ADCPrescTable[((RCC->CFGR & RCC_CFGR_ADCPRE) >> 14)]; //ADCCLK ��� 14MHz
//  nu32_CLK_ADC = nu32_CLK_APB2 / tmp;
//  return nu32_CLK_ADC;
//}

//u32  MyMcu_GetClk_APB1(void)     { return nu32_CLK_APB1; }
//u32  MyMcu_GetClk_APB2(void)     { return nu32_CLK_APB2; }
//u32  MyMcu_GetClk_APB1_TIM(void) { return nu32_CLK_APB1_TIM; }
//u32  MyMcu_GetClk_APB2_TIM(void) { return nu32_CLK_APB2_TIM; }

////ע��
////1. ���޸� AFIO_MAPR �Ĵ���֮ǰҪʹ�� AFIO ��ʱ�ӣ�����˼Ĵ���д����ȥ
////2. PB3 ������ JTDO ������ SW �ĸ����ź� TRACESWO ���������ͨ IO ��Ҫ�� keil ��
////�ص����٣����� PB3 ��һֱ�������
////3. keil ���ø���ʵ���ϻ�ͨ��������Ӱ�� DBGMCU_CR(0xE0042004) �Ĵ����� 5~7 λ
////������Ĵ����ȸ�λ����Ч��
//void MyMcu_Disable_Jtag(void)
//{
//  RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
//  GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);
//}
//-----------------------------------------------------------------------------

//------------------------------------EOF--------------------------------------





