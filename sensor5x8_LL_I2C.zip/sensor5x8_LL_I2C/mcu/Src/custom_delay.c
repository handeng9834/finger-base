#include "custom_delay.h"

// 定义一个常量，表示每微秒所需的NOP指令数量
// 假设每个NOP指令占用一个CPU周期。如果不是，需要调整这个值。
#define NOP_PER_US (SystemCoreClock / 1000000U)

/**
  * @brief  提供微秒级延时。
  * @param  us: 延时时间，单位微秒 (µs)。
  * @retval None
  */
void Delay_us(uint32_t us)
{
    uint32_t i = 0;
    // 计算需要执行的NOP指令总数
    uint32_t NOP_count = us * NOP_PER_US;

    for (i = 0; i < NOP_count; i++)
    {
        __NOP();
    }
} 
/**
  * @brief  毫秒级延时
  * @param  xms 延时时长，范围：0~4294967295
  * @retval 无
  */
void Delay_ms(uint32_t xms)
{
	while(xms--)
	{
		Delay_us(1000);
	}
}
 
/**
  * @brief  秒级延时
  * @param  xs 延时时长，范围：0~4294967295
  * @retval 无
  */
void Delay_s(uint32_t xs)
{
	while(xs--)
	{
		Delay_ms(1000);
	}
} 
