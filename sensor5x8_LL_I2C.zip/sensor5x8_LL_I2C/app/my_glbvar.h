#ifndef __MY_GLBVAR_H
#define __MY_GLBVAR_H

//----------------------------------Include------------------------------------
#include  "my_type_rdf.h"
//-----------------------------------------------------------------------------

//-----------------------------------Macro-------------------------------------
#define countof(Obj)  (sizeof(Obj)/sizeof(Obj[0]))
#define COL_SIZE      8
#define ROW_SIZE      5
#define	NOFCHANEL			5
#define	AD_REF_Value	0xE8B		//����Ӳ���˷Ųο���ѹ3.0V����

#define	My_DBG				1				// =1 Ϊ����ģʽ�������ɴ��ڷ����� =0Ϊ����ģʽ��������I2C����
//-----------------------------------------------------------------------------
#define BSWAP_16(x) \
    (uint16_t)((((uint16_t)(x) & 0x00ff) << 8) | \
               (((uint16_t)(x) & 0xff00) >> 8) \
              )


#define	PWM_VALUE_ADDR								0						//PWM����ֵ�����EEPROM��0��ַ������Ϊ1�ֽ�
#define	SLAVEADDR_VALUE_ADDR					1						//I2C�豸��ַ�����EEPROM��1��ַ������Ϊ1�ֽ�				
//-----------------------------------------------------------------------------

//-----------------------------------Types-------------------------------------
//-----------------------------------------------------------------------------

//---------------------------------Share Var-----------------------------------
#ifdef  MYAPP_GLOBALS
#else
extern  u64           igu64_tick_ms;

#if My_DBG
	extern volatile u16 	ADC_ConvertedValue[NOFCHANEL];
#else
	extern volatile u16 	ADC_ConvertedValue[NOFCHANEL+1];
#endif




extern  u16           gu16_data[];
//extern	u16						data_header[];
//extern  u16           gu16_pre[];

extern	u8						SLAVE_OWN_ADDRESS;
extern	u8						addr_reg[],pwm_reg[];


#endif
//-----------------------------------------------------------------------------

#endif
//------------------------------------EOF--------------------------------------

