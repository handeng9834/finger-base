#ifndef  __MYMCU_UART_H
#define  __MYMCU_UART_H

//----------------------------------Include------------------------------------
#include "my_type_rdf.h"
#include "stm32l0xx_ll_gpio.h"
#include "stm32l0xx_ll_bus.h"
#include "stm32l0xx_ll_rcc.h"
//-----------------------------------------------------------------------------

///* USART2 instance is used. (TX on PB.06, RX on PB.07)
//   (please ensure that USART communication between the target MCU and ST-LINK MCU is properly enabled 
//    on HW board in order to support Virtual Com Port) */

#define USARTx_INSTANCE               USART2
#define USARTx_CLK_ENABLE()           LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_USART2)
#define USARTx_CLK_SOURCE()           LL_RCC_SetUSARTClockSource(LL_RCC_USART2_CLKSOURCE_PCLK1)
#define USARTx_IRQn                   USART2_IRQn
#define USARTx_IRQHandler             USART2_IRQHandler

#define USARTx_GPIO_CLK_ENABLE()      LL_IOP_GRP1_EnableClock(LL_IOP_GRP1_PERIPH_GPIOB)   /* Enable the peripheral clock of GPIOB */
#define USARTx_TX_PIN                 LL_GPIO_PIN_6
#define USARTx_TX_GPIO_PORT           GPIOB
#define USARTx_SET_TX_GPIO_AF()       LL_GPIO_SetAFPin_0_7(GPIOB, LL_GPIO_PIN_6, LL_GPIO_AF_0)
#define USARTx_RX_PIN                 LL_GPIO_PIN_7
#define USARTx_RX_GPIO_PORT           GPIOB
#define USARTx_SET_RX_GPIO_AF()       LL_GPIO_SetAFPin_0_7(GPIOB, LL_GPIO_PIN_7, LL_GPIO_AF_0)


/* USART2 instance is used. (TX on PA.02, RX on PA.03)
   (please ensure that USART communication between the target MCU and ST-LINK MCU is properly enabled 
    on HW board in order to support Virtual Com Port) */
//#define USARTx_INSTANCE               USART2
//#define USARTx_CLK_ENABLE()           LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_USART2)
//#define USARTx_CLK_SOURCE()           LL_RCC_SetUSARTClockSource(LL_RCC_USART2_CLKSOURCE_PCLK1)
//#define USARTx_IRQn                   USART2_IRQn
//#define USARTx_IRQHandler             USART2_IRQHandler

//#define USARTx_GPIO_CLK_ENABLE()      LL_IOP_GRP1_EnableClock(LL_IOP_GRP1_PERIPH_GPIOA)   /* Enable the peripheral clock of GPIOA */
//#define USARTx_TX_PIN                 LL_GPIO_PIN_2
//#define USARTx_TX_GPIO_PORT           GPIOA
//#define USARTx_SET_TX_GPIO_AF()       LL_GPIO_SetAFPin_0_7(GPIOA, LL_GPIO_PIN_2, LL_GPIO_AF_4)
//#define USARTx_RX_PIN                 LL_GPIO_PIN_3
//#define USARTx_RX_GPIO_PORT           GPIOA
//#define USARTx_SET_RX_GPIO_AF()       LL_GPIO_SetAFPin_0_7(GPIOA, LL_GPIO_PIN_3, LL_GPIO_AF_4)
//----------------------------------Declare------------------------------------
void MyMcu_Init_Uart2(u32 baud);
void MyMcu_Uart2_Send(char* pdata, u32 len);


//void MyMcu_Init_Uart2(u32 baud);
void MyMcu_Uart2_SendStr(char* str);
void MyMcu_Uart2_Printf(char *fmt, ...);
//void MyMcu_Uart2_IntRxEn(u32 en);
//-----------------------------------------------------------------------------

#endif
//------------------------------------EOF--------------------------------------



