//----------------------------------Include------------------------------------
#include  <stdio.h>
#include  <stdarg.h>
#include  <string.h>
#include "my_type_rdf.h"
#include "stm32l0xx_ll_gpio.h"
#include "stm32l0xx_ll_usart.h"
#include "mymcu_uart.h"
#include "my_cmd.h"
//-----------------------------------------------------------------------------

//-----------------------------------Macro-------------------------------------
//#define _UART              USART2        //PA9--Tx  PA10--Rx
//#define _DMA               DMA1          //DMA1 Channel_4 -- USART1_TX
//#define _CHN               4
//#define _DMA_CHN           DMA1_Channel4


//-----------------------------------------------------------------------------
/**
  * @brief  This function configures USARTx Instance.
  * @note   This function is used to :
  *         -1- Enable GPIO clock and configures the USART pins.
  *         -2- NVIC Configuration for USART interrupts.
  *         -3- Enable the USART peripheral clock and clock source.
  *         -4- Configure USART functional parameters.
  *         -5- Enable USART.
  * @note   Peripheral configuration is minimal configuration from reset values.
  *         Thus, some useless LL unitary functions calls below are provided as
  *         commented examples - setting is default configuration from reset.
  * @param  None
  * @retval None
  */
//-----------------------------------------------------------------------------

//--------------------------------Public Func----------------------------------
void MyMcu_Init_Uart2(u32 baud)
{
	/* (1) Enable GPIO clock and configures the USART pins *********************/

  /* Enable the peripheral clock of GPIO Port */
  USARTx_GPIO_CLK_ENABLE();

  /* Configure Tx Pin as : Alternate function, High Speed, Push pull, Pull up */
  LL_GPIO_SetPinMode(USARTx_TX_GPIO_PORT, USARTx_TX_PIN, LL_GPIO_MODE_ALTERNATE);
  USARTx_SET_TX_GPIO_AF();
  LL_GPIO_SetPinSpeed(USARTx_TX_GPIO_PORT, USARTx_TX_PIN, LL_GPIO_SPEED_FREQ_HIGH);
  LL_GPIO_SetPinOutputType(USARTx_TX_GPIO_PORT, USARTx_TX_PIN, LL_GPIO_OUTPUT_PUSHPULL);
  LL_GPIO_SetPinPull(USARTx_TX_GPIO_PORT, USARTx_TX_PIN, LL_GPIO_PULL_UP);

  /* Configure Rx Pin as : Alternate function, High Speed, Push pull, Pull up */
  LL_GPIO_SetPinMode(USARTx_RX_GPIO_PORT, USARTx_RX_PIN, LL_GPIO_MODE_ALTERNATE);
  USARTx_SET_RX_GPIO_AF();
  LL_GPIO_SetPinSpeed(USARTx_RX_GPIO_PORT, USARTx_RX_PIN, LL_GPIO_SPEED_FREQ_HIGH);
  LL_GPIO_SetPinOutputType(USARTx_RX_GPIO_PORT, USARTx_RX_PIN, LL_GPIO_OUTPUT_PUSHPULL);
  LL_GPIO_SetPinPull(USARTx_RX_GPIO_PORT, USARTx_RX_PIN, LL_GPIO_PULL_UP);

  /* (2) NVIC Configuration for USART interrupts */
  /*  - Set priority for USARTx_IRQn */
  /*  - Enable USARTx_IRQn */
  NVIC_SetPriority(USARTx_IRQn, 0);  
  NVIC_EnableIRQ(USARTx_IRQn);

  /* (3) Enable USART peripheral clock and clock source ***********************/
  USARTx_CLK_ENABLE();

  /* Set clock source */
  USARTx_CLK_SOURCE();

  /* (4) Configure USART functional parameters ********************************/
  
  /* Disable USART prior modifying configuration registers */
  /* Note: Commented as corresponding to Reset value */
  // LL_USART_Disable(USARTx_INSTANCE);

  /* TX/RX direction */
  LL_USART_SetTransferDirection(USARTx_INSTANCE, LL_USART_DIRECTION_TX_RX);

  /* 8 data bit, 1 start bit, 1 stop bit, no parity */
  LL_USART_ConfigCharacter(USARTx_INSTANCE, LL_USART_DATAWIDTH_8B, LL_USART_PARITY_NONE, LL_USART_STOPBITS_1);

  /* No Hardware Flow control */
  /* Reset value is LL_USART_HWCONTROL_NONE */
  // LL_USART_SetHWFlowCtrl(USARTx_INSTANCE, LL_USART_HWCONTROL_NONE);

  /* Oversampling by 16 */
  /* Reset value is LL_USART_OVERSAMPLING_16 */
  //LL_USART_SetOverSampling(USARTx_INSTANCE, LL_USART_OVERSAMPLING_16);

  /* Set Baudrate to 115200 using APB frequency set to 16000000 Hz */
  /* Frequency available for USART peripheral can also be calculated through LL RCC macro */
  /* Ex :
      Periphclk = LL_RCC_GetUSARTClockFreq(Instance); or LL_RCC_GetUARTClockFreq(Instance); depending on USART/UART instance
  
      In this example, Peripheral Clock is expected to be equal to 16000000 Hz => equal to SystemCoreClock
  */
  LL_USART_SetBaudRate(USARTx_INSTANCE, SystemCoreClock, LL_USART_OVERSAMPLING_16, baud); 

  /* (5) Enable USART *********************************************************/
  LL_USART_Enable(USARTx_INSTANCE);

  /* Polling USART initialisation */
  while((!(LL_USART_IsActiveFlag_TEACK(USARTx_INSTANCE))) || (!(LL_USART_IsActiveFlag_REACK(USARTx_INSTANCE))))
  { 
  }

  /* Enable RXNE and Error interrupts */
  LL_USART_EnableIT_RXNE(USARTx_INSTANCE);
  LL_USART_EnableIT_ERROR(USARTx_INSTANCE);
}

//������������������
void MyMcu_Uart2_Send(char* pdata, u32 len)
{
  u32   i;
	
  for(i=0; i<len; i++){
		
		while (!LL_USART_IsActiveFlag_TXE(USARTx_INSTANCE)); //�ȴ����ͼĴ���Ϊ��
			
		LL_USART_TransmitData8(USARTx_INSTANCE, pdata[i]);
		
  }
	while (!LL_USART_IsActiveFlag_TC(USARTx_INSTANCE));   //�ȴ��������
}

//���������������ַ���
void MyMcu_Uart2_SendStr(char* str)
{ 
  u32   i=0;

  while(str[i]){
    while (!LL_USART_IsActiveFlag_TXE(USARTx_INSTANCE));
		LL_USART_TransmitData8(USARTx_INSTANCE, str[i]);
    i++;
  }
  while (!LL_USART_IsActiveFlag_TC(USARTx_INSTANCE));
}

void MyMcu_Uart2_Printf(char *fmt, ...)
{
  va_list   ap;
  char      str[256];

  va_start(ap,  fmt);
  vsprintf(str, fmt, ap);
  MyMcu_Uart2_SendStr(str);
  va_end(ap);
}

////-----------------------------------------------------------------------------

////------------------------------------ISR--------------------------------------
void USART2_IRQHandler(void)
{
  u8   c;
  
  if(LL_USART_IsActiveFlag_RXNE(USARTx_INSTANCE) ){  //if(USART_GetITStatus(_UART, USART_IT_RXNE) != RESET)
    LL_USART_EnableIT_IDLE(USARTx_INSTANCE);    //Enable IDLE interrupt
    c = USART2->RDR;            //USART_ReceiveData(_UART);
		iMyCmd_RcvOneByte(c);
  }
  
  if(LL_USART_IsActiveFlag_TC(USARTx_INSTANCE) ){  //if(USART_GetITStatus(_UART, USART_IT_TC) != RESET)
    LL_USART_ClearFlag_TC(USARTx_INSTANCE);    //USART_ClearFlag(_UART, USART_FLAG_TC);
//    _DIR_IN();
    LL_USART_DisableIT_TC(USARTx_INSTANCE);    //USART_ITConfig(_UART, USART_IT_TC, DISABLE);
    LL_USART_EnableIT_RXNE(USARTx_INSTANCE);    //USART_ITConfig(_UART, USART_IT_RXNE, ENABLE);
  }
  
   if(LL_USART_IsActiveFlag_IDLE(USARTx_INSTANCE)){  //IDLE
    LL_USART_ClearFlag_IDLE(USARTx_INSTANCE);				//Clear IDLE line detected Flag
    LL_USART_DisableIT_IDLE(USARTx_INSTANCE);    //Disable IDLE interrupt
    iMyCmd_RcvDone();
  }
}

//void DMA1_Channel4_IRQHandler(void)
//{
//  if(_DMA->ISR & (1<<((_CHN-1)*4+1)) ){   //DMA_GetITStatus(DMA1_IT_TC4)
//    _DMA->IFCR = (1<<((_CHN-1)*4+1));     //DMA_ClearITPendingBit(DMA1_IT_TC4)
//    
//    _DMA_CHN->CCR &= ~0x1;
//    _UART->SR     &= ~(1<<6);  //�ر�ע������Ҫ���TCλ������485�п��ܷ�����ȫ
//    _UART->CR1    |=  (1<<6);  //USART_ITConfig(_UART, USART_IT_TC, ENABLE)
//  }

//  if(_DMA->ISR & (1<<((_CHN-1)*4+3)) ){   //DMA_GetITStatus(DMA1_IT_TE4)
//    _DMA->IFCR = (1<<((_CHN-1)*4+3));     //DMA_ClearITPendingBit(DMA1_IT_TE4)
//  }
//}




//------------------------------------EOF--------------------------------------


