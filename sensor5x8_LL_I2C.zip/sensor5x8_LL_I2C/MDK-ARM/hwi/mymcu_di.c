//----------------------------------Include------------------------------------
#include "my_type_rdf.h"
#include "my_cfg.h"
#include "my_glbvar.h"
//-----------------------------------------------------------------------------

//-----------------------------------Macro-------------------------------------
//-----------------------------------------------------------------------------

//------------------------------------Type-------------------------------------
//-----------------------------------------------------------------------------

//-----------------------------------Const-------------------------------------
//-----------------------------------------------------------------------------

//---------------------------------Static Var----------------------------------
//-----------------------------------------------------------------------------

//--------------------------------Static Func----------------------------------
//-----------------------------------------------------------------------------

//--------------------------------Public Func----------------------------------
void MyMcu_Init_DI(void)
{
  GPIO_InitTypeDef    GPIO_InitS;
  
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
  
//Input
  GPIO_StructInit(&GPIO_InitS);
  GPIO_InitS.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitS.GPIO_Mode  = GPIO_Mode_IPU;
  
  //PC13 -- Addr0
  GPIO_InitS.GPIO_Pin = GPIO_Pin_13;  GPIO_Init(GPIOC, &GPIO_InitS);
  //PC14 -- Addr1
  GPIO_InitS.GPIO_Pin = GPIO_Pin_14;  GPIO_Init(GPIOC, &GPIO_InitS);
  //PC15 -- Addr2
  GPIO_InitS.GPIO_Pin = GPIO_Pin_15;  GPIO_Init(GPIOC, &GPIO_InitS);
  //PA6  -- Addr3
  GPIO_InitS.GPIO_Pin = GPIO_Pin_6;   GPIO_Init(GPIOA, &GPIO_InitS);
  //PA4  -- Addr4
  GPIO_InitS.GPIO_Pin = GPIO_Pin_4;   GPIO_Init(GPIOA, &GPIO_InitS);
  //PB0  -- Addr5
  GPIO_InitS.GPIO_Pin = GPIO_Pin_5;   GPIO_Init(GPIOB, &GPIO_InitS);
  
  gu8_addr = (PCin(13) | (PCin(14)<<1) | (PCin(15)<<2) | (PAin(6)<<3) | (PAin(4)<<4) | (PBin(0)<<5));
  
  //gu8_addr = (~gu8_addr)&0x3F;
}
//-----------------------------------------------------------------------------

//------------------------------------EOF--------------------------------------



