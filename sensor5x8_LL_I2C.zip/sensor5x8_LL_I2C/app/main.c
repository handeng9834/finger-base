/**
  ******************************************************************************
  * @file    Templates_LL/Src/main.c 
  * @author  MCD Application Team
  * @brief   Main program body through the LL API
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2016 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
//#include "main.h"
#include <stdio.h>
#include "my_type_rdf.h"
#include "my_mcu.h"
#include "my_glbvar.h"
#include  "my_flash.h"
#include "ICM-20602.h"
#include "custom_delay.h"
#include "mymcu_mlx90632.h"
#include "mymcu_i2c.h"
#include <string.h>

/** @addtogroup STM32L0xx_LL_Examples
  * @{
  */

/** @addtogroup Templates_LL
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/**
  * @brief  Main program
  * @param  None
  * @retval None
  */
	
/* Implementation of reading all calibration parameters for calucation of Ta and To */
/* ��ȡ����У׼�������ڼ���Ta��To��ʵ�� */
static int mlx90632_read_eeprom(int32_t *PR, int32_t *PG, int32_t *PO, int32_t *PT, int32_t *Ea, int32_t *Eb, int32_t *Fa, int32_t *Fb, int32_t *Ga, int16_t *Gb, int16_t *Ha, int16_t *Hb, int16_t *Ka)
{
	int32_t ret;
	// ��ȡEEPROM�е�У׼����
	ret = mlx90632_i2c_read32(MLX90632_EE_P_R, (uint32_t *) PR);
	if(ret < 0)
		return ret;
	ret = mlx90632_i2c_read32(MLX90632_EE_P_G, (uint32_t *) PG);
	if(ret < 0)
		return ret;
	ret = mlx90632_i2c_read32(MLX90632_EE_P_O, (uint32_t *) PO);
	if(ret < 0)
		return ret;
	ret = mlx90632_i2c_read32(MLX90632_EE_P_T, (uint32_t *) PT);
	if(ret < 0)
		return ret;
	ret = mlx90632_i2c_read32(MLX90632_EE_Ea, (uint32_t *) Ea);
	if(ret < 0)
		return ret;
	ret = mlx90632_i2c_read32(MLX90632_EE_Eb, (uint32_t *) Eb);
	if(ret < 0)
		return ret;
	ret = mlx90632_i2c_read32(MLX90632_EE_Fa, (uint32_t *) Fa);
	if(ret < 0)
		return ret;
	ret = mlx90632_i2c_read32(MLX90632_EE_Fb, (uint32_t *) Fb);
	if(ret < 0)
		return ret;
	ret = mlx90632_i2c_read32(MLX90632_EE_Ga, (uint32_t *) Ga);
	if(ret < 0)
		return ret;
	ret = mlx90632_i2c_read(MLX90632_EE_Gb, (uint16_t *) Gb);
	if(ret < 0)
		return ret;
	ret = mlx90632_i2c_read(MLX90632_EE_Ha, (uint16_t *) Ha);
	if(ret < 0)
		return ret;
	ret = mlx90632_i2c_read(MLX90632_EE_Hb, (uint16_t *) Hb);
	if(ret < 0)
		return ret;
	ret = mlx90632_i2c_read(MLX90632_EE_Ka, (uint16_t *) Ka);
	if(ret < 0)
		return ret;
	return 0;
}


double pre_ambient, pre_object, ambient, object;// �¶���ر���
uint64_t tick_ms = 0;// ϵͳʱ�����
uint16_t temp_data[2];//�¶�����
uint16_t proximity_data;//�ӽ���



int main(void)
{
//  uint32_t	i2c_temp = 0;
	uint64_t  t_tmp;
	u8						iic_temp[8] = {0};
	#if My_DBG 
		u16     temp_gu16_data[COL_SIZE*ROW_SIZE ];
	#endif
	
	/* Configure the system clock to 32 MHz */
	MyBrd_InitMcu();
//	I2C1_Ram_Init();
	
	EEPROM_ReadBytes(SLAVEADDR_VALUE_ADDR,addr_reg,1);
	SLAVE_OWN_ADDRESS = (addr_reg[0] << 1);
	
	#if My_DBG
		MyMcu_Init_Uart2(115200);
	#else
		I2C1_Slave_Init();
	#endif

	/* Check the internal version and prepare a clean start */
	mlx90632_init();//�¶ȳ�ʼ��
  INIT_VCNL36825T();//�ӽ�����������ʼ��	
  icm20602_init(); // ��̬оƬ��ʼ��

  gyroOffsetInit(); // �����Ǿ�̬��ƫУ׼

	EEPROM_ReadBytes(PWM_VALUE_ADDR,pwm_reg,1);
	Configure_DutyCycle(pwm_reg[0]);
	// ��������Ҫ���õ���7λI2C�ӻ���ַ
  uint8_t new_slave_7bit_address = 0x54; // ���µ�I2C��7λ��ַ����Ϊ 0x54
  EEPROM_WriteBytes(SLAVEADDR_VALUE_ADDR,&new_slave_7bit_address,1);//��ʼ����ַ
	
	
	
	
  /* Add your application code here */
//	i2c_temp = read_i2c_OAR1reg();

	/* Definition of MLX90632 calibration parameters */
	int16_t ambient_new_raw;
	int16_t ambient_old_raw;
	int16_t object_new_raw;
	int16_t object_old_raw;
	int32_t PR = 0x00587f5b;
	int32_t PG = 0x04a10289;
	int32_t PT = 0xfff966f8;
	int32_t PO = 0x00001e0f;
	int32_t Ea = 4859535;
	int32_t Eb = 5686508;
	int32_t Fa = 53855361;
	int32_t Fb = 42874149;
	int32_t Ga = -14556410;
	int16_t Ha = 16384;
	int16_t Hb = 0;
	int16_t Gb = 9728;
	int16_t Ka = 10752;

	/* Put the device in sleeping step mode in order to safely read the EEPROM */
	mlx90632_set_meas_type(MLX90632_MTYP_MEDICAL_BURST);
	/* Read EEPROM calibration parameters */
	mlx90632_read_eeprom(&PR, &PG, &PO, &PT, &Ea, &Eb, &Fa, &Fb, &Ga, &Gb, &Ha, &Hb, &Ka);
	/* Set continuous medical/standard measurement mode */
	mlx90632_set_meas_type(MLX90632_MTYP_MEDICAL);
	
  /* Infinite loop */
	t_tmp = igu64_tick_ms;
//	memcpy(&g_i2c_send_buffer[0], data_header, 2);
//	g_i2c_send_buffer[0] = 0xFF;
//	g_i2c_send_buffer[1] = 0xFF;
  while (1)
  {
		if(igu64_tick_ms > t_tmp + 499){
			t_tmp = igu64_tick_ms; 
//			MyMcu_LED_Toggle();
//			i2c_ReadBytes(&(iic_temp[0]),  SLAVE_MLX90632_Addr,MLX90632_EE_VERSION, 2);
//			i2c_ReadBytes(&(iic_temp[2]),  SLAVE_MLX90632_Addr,MLX90632_EE_I2C_ADDRESS, 2);
			
//			i2c_ReadBytes(&(iic_temp[2]),  SLAVE_ICM20602_Addr,SLAVE_ICM20602_ID_REG, 1);
			i2c_WriteWord(0x0A5A, SLAVE_VCNL36825T_Addr,VCNL36825T_PS_THDL);
//			i2c_ReadBytes(&(iic_temp[4]),  SLAVE_VCNL36825T_Addr,VCNL36825T_PS_THDL, 2);
//			i2c_ReadBytes(&(iic_temp[6]),  SLAVE_VCNL36825T_Addr,VCNL36825T_PS_THDH, 2);
			
			/* Get raw data from MLX90632 */
			mlx90632_read_temp_raw(&ambient_new_raw, &ambient_old_raw, &object_new_raw, &object_old_raw);
//			/* Pre-calculations for ambient and object temperature calculation */
			pre_ambient = mlx90632_preprocess_temp_ambient(ambient_new_raw, ambient_old_raw, Gb);
			pre_object = mlx90632_preprocess_temp_object(object_new_raw, object_old_raw, ambient_new_raw, ambient_old_raw, Ka);
//			/* Set emissivity = 1 */
			mlx90632_set_emissivity(1.0);
//			/* Calculate ambient and object temperature */
			ambient = mlx90632_calc_temp_ambient(ambient_new_raw, ambient_old_raw, PT, PR, PG, PO, Gb);//�����¶�
			object = mlx90632_calc_temp_object(pre_object, pre_ambient, Ea, Eb, Ga, Fa, Fb, Ha, Hb);//�����¶�

      temp_data[0] = (uint16_t)(ambient * 100);  // �Ŵ��¶�����100������2λС��
      temp_data[1] = (uint16_t)(object * 100);
			
			i2c_ReadBytes((uint8_t*)&proximity_data, SLAVE_VCNL36825T_Addr, VCNL36825T_PS_DATA, 2);
			
      icm20602_read_raw(&icm_raw_data.acc_x, &icm_raw_data.gyro_x); // ��ȡ��̬ԭʼ���ݲ�����icm_raw_data

      // �����ݸ��Ƶ�I2C���ͻ�����
//      memcpy(&g_i2c_send_buffer[0], data_header, 2);
      memcpy(&g_i2c_send_buffer[2], gu16_data, COL_SIZE * ROW_SIZE * 2);
      memcpy(&g_i2c_send_buffer[2 + COL_SIZE * ROW_SIZE * 2], temp_data, sizeof(temp_data));
      memcpy(&g_i2c_send_buffer[2 + COL_SIZE * ROW_SIZE * 2 + sizeof(temp_data)], &proximity_data, sizeof(proximity_data));
      memcpy(&g_i2c_send_buffer[2 + COL_SIZE * ROW_SIZE * 2 + sizeof(temp_data) + sizeof(proximity_data)], &icm_raw_data, sizeof(icm_raw_data));

			#if My_DBG
				for(u8 i = 0;i<COL_SIZE*ROW_SIZE;i++){
					temp_gu16_data[i] = BSWAP_16(gu16_data[i]);
				}
//				MyMcu_Uart2_Printf("AD1_CH5 value is %1.3f mV",(gu16_data[0] * 3.3 /4096));
//				MyMcu_Uart2_Printf("\r\n");
//				MyMcu_Uart2_Send((char*)data_header,2);
				MyMcu_Uart2_Send((char*)(temp_gu16_data),COL_SIZE*ROW_SIZE*2);
				MyMcu_Uart2_Send((char*)temp_data, sizeof(temp_data));//�����¶�����
				MyMcu_Uart2_Send((char*)&proximity_data, sizeof(proximity_data));  // ���ӽӽ����ݴ���
        MyMcu_Uart2_Send((char*)&icm_raw_data, sizeof(icm_raw_data));//������̬ԭʼ����
			#endif
			
			
//			MyMcu_Uart2_Send((char*)ADC_ConvertedValue,NOFCHANEL*2);
//			MyMcu_Uart2_Printf("AD1_CH5 value is %1.3f mV",(ADC_ConvertedValue[0] * 3.3 /4096));
//			MyMcu_Uart2_Printf("\r\n");
//			MyMcu_Uart2_Printf("AD1_CH6 value is %1.3f mV",(ADC_ConvertedValue[1] * 3.3 /4096));
//			MyMcu_Uart2_Printf("\r\n");
		}
//		MyMcu_LED_Toggle();
		
		#if My_DBG
			MyCyc_Cmd();
		#endif
  }
}

/* ==============   BOARD SPECIFIC CONFIGURATION CODE END      ============== */

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
