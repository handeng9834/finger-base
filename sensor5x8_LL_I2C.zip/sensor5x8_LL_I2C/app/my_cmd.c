//----------------------------------Include------------------------------------
#include  <string.h>
#include  <stdlib.h>
//#include  "my_type_rdf.h"
#include  "my_mcu.h"
#include  "my_glbvar.h"
#include  "my_flash.h"
//-----------------------------------------------------------------------------

//-----------------------------------Macro-------------------------------------
//#define _OUT_STR(s)      do{ MyMcu_Uart1_SendStr(s);     }while(0)
//#define _OUT_PRINTF      MyMcu_Uart1_Printf
//#define _OUT_DATA        MyMcu_Uart1_Send
//-----------------------------------------------------------------------------
#define RXBUF_LEN           16
//-----------------------------------------------------------------------------

//------------------------------------Type-------------------------------------
typedef struct{
  u32   cnt;
  u8    done;
  char  data[RXBUF_LEN];
}t_rcv;
//-----------------------------------------------------------------------------

//---------------------------------Static Var----------------------------------
static t_rcv    nt_rcv;
//-----------------------------------------------------------------------------

//--------------------------------Static Func----------------------------------
int tolower(int c)
{
  if ((c >= 'A') && (c <= 'Z'))
    return c + ('a' - 'A');
  return c;
}

int toupper(int c)
{
  if ((c >= 'a') && (c <= 'z'))
    return c + ('A' - 'a');
  return c;
}

char *strupr(char *str)
{
  char *orign=str;
  for (; *str!='\0'; str++)
    *str = toupper(*str);
  return orign;
}

char *strlowr(char *str)
{
  char *orign=str;
  for (; *str!='\0'; str++)
    *str = tolower(*str);
  return orign;
}
//-----------------------------------------------------------------------------

//--------------------------------Public Func----------------------------------
void iMyCmd_RcvOneByte(u8 c)
{ 
  if(nt_rcv.cnt >= RXBUF_LEN) nt_rcv.cnt = 0;
  nt_rcv.data[nt_rcv.cnt++] = c;
}

void iMyCmd_RcvDone(void)
{
  nt_rcv.done = 1;
}

void MyCyc_Cmd(void)
{
  char*  st;
  char*  p;
//  u8     col, row, addr;
  u8    pwm[1];
//  u16    i;
  
  if(!nt_rcv.done) return;
 // MyMcu_LED_Toggle();
  
//  if(nt_rcv.cnt <  4)         { _OUT_STR("Invalid command\r\n"); goto end; }
//  if(nt_rcv.cnt == RXBUF_LEN) { _OUT_STR("Too Full!\r\n");       goto end; }
  if(nt_rcv.data[0] != ':')   goto end;
  
  nt_rcv.data[nt_rcv.cnt] = 0;
  st = &nt_rcv.data[0];
//  st = strlowr(st);
  //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  if      ( !strncmp(st, ":data",   5) ){
   p = strstr(st, ":data");
////////    MyMcu_Uart2_SendStr(":slave");
////////		MyMcu_Uart2_Send((char*)gu16_data, (COL_SIZE*ROW_SIZE)*2 + 2); 
////////		MyMcu_LED_Toggle(); 
  }else if( !strncmp(st, ":pwm",    4) ){
    p = strstr(st, ":pwm");
    pwm[0] = atoi(p + strlen(":pwm"));
//		FLASH_WriteMoreData(p_PWM_Duty, pwm, 1);
//		_OUT_PRINTF("PWM is written into flash at address 0x%02X%\r\n", p_PWM_Duty);
//    MyMcu_PWM_SetDuty(pwm[0]);
		EEPROM_WriteBytes(PWM_VALUE_ADDR,pwm,1);
		Configure_DutyCycle(pwm[0]);
//    _OUT_PRINTF("PWM is %02d%%\r\n", pwm[0]);
  
  }else if( !strncmp(st, ":threshold",   10) ){
    p = strstr(st, ":threshold");
//		threshold[0] = atoi(p + strlen(":threshold"));
//		FLASH_WriteMoreData(p_threshold, threshold, 1);
//		_OUT_PRINTF("threshold is written into flash at address 0x%02X%\r\n", p_threshold);
//    _OUT_PRINTF("threshold is %02d%mV\r\n", threshold[0]);
	}
////////	else if( !strncmp(st, ":c",      2) ){
////////    gu8_dbg = 1;
////////    p = strchr(st, 'c');    col = atoi(p+1);
////////    p = strchr(st, 'r');    row = atoi(p+1);
////////    MyMcu_Set_Pos(col, row);
////////    _OUT_PRINTF("Pos is col %02d, row %02d\r\n", col, row);
////////  }
  //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
end:
  nt_rcv.done = 0;
  nt_rcv.cnt  = 0;
	
}

//-------------------------------------EOF-------------------------------------

/*
void MyCyc_Cmd(void)
{
  char*  st;
  char*  p;
  int    col, row;
  
  if(!nt_rcv.done) return;
  
  if(nt_rcv.cnt <  4)         { _OUT_STR("Invalid command\r\n"); goto end; }
  if(nt_rcv.cnt == RXBUF_LEN) { _OUT_STR("Too Full!\r\n");       goto end; }
  
  nt_rcv.data[nt_rcv.cnt] = 0;
  st = &nt_rcv.data[0];
  st = strupr(st);
  //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  p = strchr(st, 'C');    col = atoi(p+1);
  p = strchr(st, 'R');    row = atoi(p+1);
  MyMcu_Set_Pos(col, row);
  _OUT_PRINTF("Pos is col %02d, row %02d\r\n", col, row);
  //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  
  //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
end:
  nt_rcv.done = 0;
  nt_rcv.cnt  = 0;
}
*/


