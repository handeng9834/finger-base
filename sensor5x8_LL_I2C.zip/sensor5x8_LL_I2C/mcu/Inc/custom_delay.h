#ifndef __CUSTOM_DELAY_H
#define __CUSTOM_DELAY_H

#ifdef __cplusplus
 extern "C" {
#endif

#include "stm32l0xx_hal.h" // 包含HAL库头文件以获取SystemCoreClock

void Delay_us(uint32_t us);
void Delay_ms(uint32_t xms);

#ifdef __cplusplus
}
#endif

#endif /* __CUSTOM_DELAY_H */ 

