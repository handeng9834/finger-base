//----------------------------------Include------------------------------------
#define  MYAPP_GLOBALS
#include "my_glbvar.h"
//-----------------------------------------------------------------------------

//---------------------------------Global Var----------------------------------
u64           igu64_tick_ms;

#if My_DBG
	volatile u16 ADC_ConvertedValue[NOFCHANEL+1] = {0};
#else
	volatile u16 ADC_ConvertedValue[NOFCHANEL+1] = {0};
#endif


//u16						data_header[1]	=	{0x0011};
//u16           gu16_data[COL_SIZE*ROW_SIZE + 10] = {0xFFFF,};
	u16           gu16_data[COL_SIZE*ROW_SIZE] ;
//u16           gu16_pre[COL_SIZE*ROW_SIZE];

u8            SLAVE_OWN_ADDRESS	;
u8						addr_reg[1],pwm_reg[1];



//-----------------------------------------------------------------------------

//------------------------------------EOF--------------------------------------

