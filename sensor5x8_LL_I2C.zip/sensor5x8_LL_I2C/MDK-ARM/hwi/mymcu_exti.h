#ifndef __EXTI_H
#define	__EXTI_H


//���Ŷ���
#define COL_EN_GPIO_PORT       				GPIOB
#define COL_EN_GPIO_CLK        				(RCC_APB2Periph_GPIOB|RCC_APB2Periph_AFIO)
#define COL_EN_GPIO_PIN        				GPIO_Pin_13
#define COL_EN_EXTI_PORTSOURCE   			GPIO_PortSourceGPIOB
#define COL_EN_EXTI_PINSOURCE    			GPIO_PinSource13
#define COL_EN_EXTI_LINE         			EXTI_Line13
#define COL_EN_EXTI_IRQ          			EXTI15_10_IRQn 


#define COL_Update_GPIO_PORT       		GPIOB
#define COL_Update_GPIO_CLK        		(RCC_APB2Periph_GPIOB|RCC_APB2Periph_AFIO)
#define COL_Update_GPIO_PIN        		GPIO_Pin_14
#define COL_Update_EXTI_PORTSOURCE   	GPIO_PortSourceGPIOB
#define COL_Update_EXTI_PINSOURCE    	GPIO_PinSource14
#define COL_Update_EXTI_LINE         	EXTI_Line14
#define COL_Update_EXTI_IRQ          	EXTI15_10_IRQn 

//#define COL_Update_IRQHandler         EXTI15_10_IRQHandler


#define ROW_Update_GPIO_PORT       		GPIOB
#define ROW_Update_GPIO_CLK        		(RCC_APB2Periph_GPIOB|RCC_APB2Periph_AFIO)
#define ROW_Update_GPIO_PIN        		GPIO_Pin_15
#define ROW_Update_EXTI_PORTSOURCE   	GPIO_PortSourceGPIOB
#define ROW_Update_EXTI_PINSOURCE    	GPIO_PinSource15
#define ROW_Update_EXTI_LINE         	EXTI_Line15
#define ROW_Update_EXTI_IRQ          	EXTI15_10_IRQn 

#define COL_ROW_Update_IRQHandler     EXTI15_10_IRQHandler

void MyMcu_Init_EXTI(void);
void	EXTI4_15_IRQHandler(void);


#endif /* __EXTI_H */
