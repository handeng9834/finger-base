/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef  __MYMCU_VCNL36825T_H
#define  __MYMCU_VCNL36825T_H

//----------------------------------Include------------------------------------
#include "my_type_rdf.h"
#include "stm32l0xx_ll_gpio.h"
#include "stm32l0xx_ll_bus.h"
#include "stm32l0xx_ll_rcc.h"
#include "my_glbvar.h"
//-----------------------------------------------------------------------------

//Table 1 Datasheet Command Code
#define VCNL36825T_PS_CONF1_L	     	0x00
#define VCNL36825T_PS_CONF1_H	     	0x00
#define VCNL36825T_PS_CONF2_L	     	0x03
#define VCNL36825T_PS_CONF2_H	     	0x03
#define VCNL36825T_PS_CONF3_L		 		0x04
#define VCNL36825T_PS_CONF3_H		 		0x04
#define VCNL36825T_PS_THDL			 		0x05
#define VCNL36825T_PS_THDH			 		0x06
#define VCNL36825T_PS_CANC			 		0x07
#define VCNL36825T_PS_CONF4_L      	0x08
#define VCNL36825T_PS_CONF4_H    	 	0x08
#define VCNL36825T_PS_DATA			 		0xF8
#define VCNL36825T_PS_INT_FLAG		 	0xF9
#define VCNL36825T_PS_ID			 			0xFA
#define VCNL36825T_PS_AC_DATA		 		0xFB

//Table 2 Datasheet Register 0x00 Low Byte
#define VCNL36825T_PS_CAL_EN		 		0x01<<7
#define VCNL36825T_PS_CAL_DIS		 		0x00<<7
#define VCNL36825T_PS_ON_EN			 		0x03<<0
#define VCNL36825T_PS_ON_DIS	     	0x00<<0

//Table 3 Datasheet Register 0x00 High Byte
//Reserved
#define VCNL36825T_PS_LDO_EN		 0x01<<1

//Table 4 Datasheet Register 0x03 Low Byte
#define VCNL36825T_PS_PERIOD_10ms	 	0x00<<6
#define VCNL36825T_PS_PERIOD_20ms	 	0x01<<6
#define VCNL36825T_PS_PERIOD_40ms	 	0x02<<6
#define VCNL36825T_PS_PERIOD_80ms	 	0x03<<6
#define VCNL36825T_PS_PERS_1		 		0x00<<4
#define VCNL36825T_PS_PERS_2		 		0x01<<4
#define VCNL36825T_PS_PERS_3		 		0x02<<4
#define VCNL36825T_PS_PERS_4		 		0x03<<4
#define VCNL36825T_PS_INT_DIS		 		0x00<<2
#define VCNL36825T_PS_INT_LOGIC		 	0x01<<2
#define VCNL36825T_PS_INT_FIRST_HIGH 	0x02<<2
#define VCNL36825T_PS_INT_EN	     		0x03<<2
#define VCNL36825T_PS_SMART_PERS_DIS 	0x00<<1
#define VCNL36825T_PS_SMART_PERS_EN	 	0x01<<1
#define VCNL36825T_PS_ST_START		 		0x00<<0
#define VCNL36825T_PS_ST_STOP		 			0x01<<0

//Table 5 Datasheet Register 0x03 High Byte
#define VCNL36825T_PS_IT_1T			 0x00<<6
#define VCNL36825T_PS_IT_2T			 0x01<<6
#define VCNL36825T_PS_IT_4T			 0x02<<6
#define VCNL36825T_PS_IT_8T			 0x03<<6
#define VCNL36825T_PS_MPS_1			 0x00<<4
#define VCNL36825T_PS_MPS_2			 0x01<<4
#define VCNL36825T_PS_MPS_4			 0x02<<4
#define VCNL36825T_PS_MPS_8			 0x03<<4
#define VCNL36825T_PS_ITB_25		 0x00<<3
#define VCNL36825T_PS_ITB_50		 0x01<<3
#define VCNL36825T_PS_HG_DIS		 0x00<<2
#define VCNL36825T_PS_HG_EN			 0x01<<2

//Table 6 Datasheet Register 0x04 Low Byte
#define VCNL36825T_PS_AF_EN			 		0x01<<6
#define VCNL36825T_PS_AUTO			 		0x00<<6
#define VCNL36825T_PS_TRIG_EN		 		0x01<<5
#define VCNL36825T_PS_TRIG_DIS		 	0x00<<5
#define VCNL36825T_PS_FORCENUM_1	 	0x00<<4
#define VCNL36825T_PS_FORCENUM_2	 	0x01<<4
#define VCNL36825T_PS_CAL_AUTO		 	0x01<<3
#define VCNL36825T_PS_SP_INT_DIS	 	0x00<<2
#define VCNL36825T_PS_SP_INT_EN		 	0x01<<2

//Table 7 Datasheet Register 0x04 High Byte
#define VCNL36825T_PS_SC_DIS		 		0x00<<5
#define VCNL36825T_PS_SC_EN 	     	0x07<<5
#define VCNL36825T_PS_HD_12Bits		 	0x00<<4
#define VCNL36825T_PS_HD_16Bits		 	0x01<<4
#define VCNL36825T_I_VCSEL_10mA		 	0x02<<0
#define VCNL36825T_I_VCSEL_12mA		 	0x03<<0
#define VCNL36825T_I_VCSEL_14mA		 	0x04<<0
#define VCNL36825T_I_VCSEL_16mA		 	0x05<<0
#define VCNL36825T_I_VCSEL_18mA		 	0x06<<0
#define VCNL36825T_I_VCSEL_20mA		 	0x07<<0

//Table 11 Datasheet Register 0x08 Low Byte
#define VCNL36825T_PS_AC_PERIOD_3ms	 0x00<<6
#define VCNL36825T_PS_AC_PERIOD_6ms	 0x01<<6
#define VCNL36825T_PS_AC_PERIOD_12ms 0x02<<6
#define VCNL36825T_PS_AC_PERIOD_24ms 0x03<<6
#define VCNL36825T_PS_AC_NUM1 		 0x00<<4
#define VCNL36825T_PS_AC_NUM2 		 0x01<<4
#define VCNL36825T_PS_AC_NUM4 		 0x02<<4
#define VCNL36825T_PS_AC_NUM8 		 0x03<<4
#define VCNL36825T_PS_AC_DIS		 0x00<<3
#define VCNL36825T_PS_AC_EN		 	 0x01<<3
#define VCNL36825T_PS_AC_TRIG_DIS	 0x00<<2
#define VCNL36825T_PS_AC_TRIG_EN	 0x01<<2
#define VCNL36825T_PS_AC_INT_DIS	 0x00<<0
#define VCNL36825T_PS_AC_INT_EN	 	 0x01<<0

//Table 12 Datasheet Register 0x08 High Byte
#define VCNL36825T_PS_LPPER_40ms	 0x00<<1
#define VCNL36825T_PS_LPPER_80ms	 0x01<<1
#define VCNL36825T_PS_LPPER_160ms 	 0x02<<1
#define VCNL36825T_PS_LPPER_320ms  	 0x03<<1
#define VCNL36825T_PS_LPEN_DIS	 	 0x00<<0
#define VCNL36825T_PS_LPEN_EN	 	 0x01<<0

#define SLAVE_VCNL36825T_Addr						(0x60 << 1)
#define SLAVE_VCNL36825T_ID_REG					0xFA					//Device ID = 0x0026



//-----------------------------------------------------------------------------

void INIT_VCNL36825T(void);

#endif
//------------------------------------EOF--------------------------------------

