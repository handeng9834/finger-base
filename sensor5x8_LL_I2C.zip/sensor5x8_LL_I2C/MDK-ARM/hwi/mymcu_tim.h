#ifndef  __MYMCU_TIM_H
#define  __MYMCU_TIM_H

//----------------------------------Include------------------------------------
#include "my_type_rdf.h"
//-----------------------------------------------------------------------------

//----------------------------------Declare------------------------------------
void MyMcu_Init_Tim21(void);

void MyMcu_Init_Tim2(void);
void Configure_DutyCycle(uint32_t D);
//void MyMcu_delay_ms(uint32_t ms);

//void MyMcu_Init_Tim3(void);
//void MyMcu_PWM_SetDuty(u8 p);
//-----------------------------------------------------------------------------

#endif
//------------------------------------EOF--------------------------------------



