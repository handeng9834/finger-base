//----------------------------------Include------------------------------------
#include "my_type_rdf.h"
//#include "my_cfg.h"
#include "mymcu_dio.h"
#include "my_glbvar.h"
//-----------------------------------------------------------------------------

//#if My_DBG
//#define LED2_PIN                           LL_GPIO_PIN_1
//#define LED2_GPIO_PORT                     GPIOB
//#define LED2_GPIO_CLK_ENABLE()             LL_IOP_GRP1_EnableClock(LL_IOP_GRP1_PERIPH_GPIOB)

//#else
//#define LED2_PIN                           LL_GPIO_PIN_4
//#define LED2_GPIO_PORT                     GPIOA
//#define LED2_GPIO_CLK_ENABLE()             LL_IOP_GRP1_EnableClock(LL_IOP_GRP1_PERIPH_GPIOA)
//#endif

//--------------------------------Public Func----------------------------------
/**
  * @brief  This function configures GPIO
  * @note   Peripheral configuration is minimal configuration from reset values.
  *         Thus, some useless LL unitary functions calls below are provided as
  *         commented examples - setting is default configuration from reset.
  * @param  None
  * @retval None
  */
	
//output
void MyMcu_Init_DO(void)
{
  /* Enable the COL_SEL2 Clock */
  COL_SEL2_GPIO_CLK_ENABLE() ;

  /* Configure IO in output push-pull mode to drive external LED2 */
  LL_GPIO_SetPinMode(COL_SEL2_GPIO_PORT, COL_SEL2_PIN, LL_GPIO_MODE_OUTPUT);
  /* Reset value is LL_GPIO_OUTPUT_PUSHPULL */
  LL_GPIO_SetPinOutputType(COL_SEL2_GPIO_PORT, COL_SEL2_PIN, LL_GPIO_OUTPUT_PUSHPULL);
  /* Reset value is LL_GPIO_SPEED_FREQ_MEDIUM */
  LL_GPIO_SetPinSpeed(COL_SEL2_GPIO_PORT, COL_SEL2_PIN, LL_GPIO_SPEED_FREQ_MEDIUM);
  /* Reset value is LL_GPIO_PULL_NO */
  //LL_GPIO_SetPinPull(COL_SEL2_GPIO_PORT, COL_SEL2_PIN, LL_GPIO_PULL_NO);
	
	/* Enable the COL_SEL1 Clock */
  COL_SEL1_GPIO_CLK_ENABLE() ;

  /* Configure IO in output push-pull mode to drive external LED2 */
  LL_GPIO_SetPinMode(COL_SEL1_GPIO_PORT, COL_SEL1_PIN, LL_GPIO_MODE_OUTPUT);
  /* Reset value is LL_GPIO_OUTPUT_PUSHPULL */
  LL_GPIO_SetPinOutputType(COL_SEL1_GPIO_PORT, COL_SEL1_PIN, LL_GPIO_OUTPUT_PUSHPULL);
  /* Reset value is LL_GPIO_SPEED_FREQ_MEDIUM */
  LL_GPIO_SetPinSpeed(COL_SEL1_GPIO_PORT, COL_SEL1_PIN, LL_GPIO_SPEED_FREQ_MEDIUM);
  /* Reset value is LL_GPIO_PULL_NO */
  //LL_GPIO_SetPinPull(COL_SEL1_GPIO_PORT, COL_SEL1_PIN, LL_GPIO_PULL_NO);
	
	/* Enable the COL_SEL0 Clock */
  COL_SEL0_GPIO_CLK_ENABLE() ;

  /* Configure IO in output push-pull mode to drive external LED2 */
  LL_GPIO_SetPinMode(COL_SEL0_GPIO_PORT, COL_SEL0_PIN, LL_GPIO_MODE_OUTPUT);
  /* Reset value is LL_GPIO_OUTPUT_PUSHPULL */
  LL_GPIO_SetPinOutputType(COL_SEL0_GPIO_PORT, COL_SEL0_PIN, LL_GPIO_OUTPUT_PUSHPULL);
  /* Reset value is LL_GPIO_SPEED_FREQ_MEDIUM */
  LL_GPIO_SetPinSpeed(COL_SEL0_GPIO_PORT, COL_SEL0_PIN, LL_GPIO_SPEED_FREQ_MEDIUM);
  /* Reset value is LL_GPIO_PULL_NO */
  //LL_GPIO_SetPinPull(COL_SEL0_GPIO_PORT, COL_SEL0_PIN, LL_GPIO_PULL_NO);
	
		/* Enable the COL_SEL_EN Clock */
  COL_SEL_EN_GPIO_CLK_ENABLE() ;

  /* Configure IO in output push-pull mode to drive external LED2 */
  LL_GPIO_SetPinMode(COL_SEL_EN_GPIO_PORT, COL_SEL_EN_PIN, LL_GPIO_MODE_OUTPUT);
  /* Reset value is LL_GPIO_OUTPUT_PUSHPULL */
  LL_GPIO_SetPinOutputType(COL_SEL_EN_GPIO_PORT, COL_SEL_EN_PIN, LL_GPIO_OUTPUT_PUSHPULL);
  /* Reset value is LL_GPIO_SPEED_FREQ_MEDIUM */
  LL_GPIO_SetPinSpeed(COL_SEL_EN_GPIO_PORT, COL_SEL_EN_PIN, LL_GPIO_SPEED_FREQ_MEDIUM);
  /* Reset value is LL_GPIO_PULL_NO */
  //LL_GPIO_SetPinPull(COL_SEL0_GPIO_PORT, COL_SEL0_PIN, LL_GPIO_PULL_NO);
	
//#if My_DBG
//	 /* Enable the LED2 Clock */
//  LED2_GPIO_CLK_ENABLE();

//  /* Configure IO in output push-pull mode to drive external LED2 */
//  LL_GPIO_SetPinMode(LED2_GPIO_PORT, LED2_PIN, LL_GPIO_MODE_OUTPUT);
//  /* Reset value is LL_GPIO_OUTPUT_PUSHPULL */
//  //LL_GPIO_SetPinOutputType(LED2_GPIO_PORT, LED2_PIN, LL_GPIO_OUTPUT_PUSHPULL);
//  /* Reset value is LL_GPIO_SPEED_FREQ_LOW */
//  //LL_GPIO_SetPinSpeed(LED2_GPIO_PORT, LED2_PIN, LL_GPIO_SPEED_FREQ_LOW);
//  /* Reset value is LL_GPIO_PULL_NO */
//  //LL_GPIO_SetPinPull(LED2_GPIO_PORT, LED2_PIN, LL_GPIO_PULL_NO);
//#endif
}



//u8 MyMcu_LED0(u8 on)
//{
//  if(on) PBout(15) = 0;
//  else   PBout(15) = 1;
//  return on;
//}

void MyMcu_Set_Pos_col(uint8_t col)
{
  if(col >= 8) return;
  
  switch(col){
    //--------Col_SEL2-----------Col_SEL1----------Col_SEL0--------//
    case 0:  Set_COL_SEL_EN_0; Set_COL_SEL2_0;   Set_COL_SEL1_1;   Set_COL_SEL0_1;   break;
		case 1:  Set_COL_SEL_EN_0; Set_COL_SEL2_1;   Set_COL_SEL1_0;   Set_COL_SEL0_1;   break;
		case 2:  Set_COL_SEL_EN_0; Set_COL_SEL2_0;   Set_COL_SEL1_0;   Set_COL_SEL0_0;   break;
		case 3:  Set_COL_SEL_EN_0; Set_COL_SEL2_1;   Set_COL_SEL1_1;   Set_COL_SEL0_1;   break;
		case 4:  Set_COL_SEL_EN_0; Set_COL_SEL2_0;   Set_COL_SEL1_0;   Set_COL_SEL0_1;   break;
		case 5:  Set_COL_SEL_EN_0; Set_COL_SEL2_1;   Set_COL_SEL1_1;   Set_COL_SEL0_0;   break;
		case 6:  Set_COL_SEL_EN_0; Set_COL_SEL2_0;   Set_COL_SEL1_1;   Set_COL_SEL0_0;   break;
		case 7:  Set_COL_SEL_EN_0; Set_COL_SEL2_1;   Set_COL_SEL1_0;   Set_COL_SEL0_0;   break;
    default: break;
  }
}

//-----------------------------------------------------------------------------

//------------------------------------EOF--------------------------------------



