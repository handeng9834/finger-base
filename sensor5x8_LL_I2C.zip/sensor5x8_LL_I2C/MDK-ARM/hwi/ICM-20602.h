#ifndef __ICM_20602_H
#define __ICM_20602_H

#include <stdio.h>
#include <stdint.h>
#include "my_mcu.h"

// 定义ICM-20602的I2C地址，SA0=1时为0x69
#define ICM20602_I2C_ADDR 0x69
#define delta_T     0.001f  // 采样周期1ms，频率1kHz
#define PI          3.1415926f
#define WHO_AM_I_ID 0x12    // 设备ID
#define I2C_WRITE   0
#define I2C_READ    1
#define RAD_TO_DEG  (180.0f/PI)

// 姿态数据结构定义
typedef struct {
    float AX;
    float AY;
    float AZ;
} ICM_Acc;  // 修改名称避免冲突

typedef struct {
    float GX;
    float GY;
    float GZ;
} ICM_Gyro;  // 修改名称避免冲突

// 四元数结构体
typedef struct {
    float q0;
    float q1;
    float q2;
    float q3;
} quater_param_t;

// 欧拉角结构体
typedef struct {
    float roll;
    float pitch;
    float yaw;
} euler_param_t;

// 陀螺仪校准值结构体
typedef struct {
    int16_t Xdata;
    int16_t Ydata;
    int16_t Zdata;
} gyro_param_t;

// 原始数据结构体
typedef struct {
    int16_t acc_x;
    int16_t acc_y;
    int16_t acc_z;
    int16_t gyro_x;
    int16_t gyro_y;
    int16_t gyro_z;
} icm_raw_data_t;

// 处理后的数据结构体
typedef struct {
    float acc_x;
    float acc_y;
    float acc_z;
    float gyro_x;
    float gyro_y;
    float gyro_z;
} icm_param_t;

// 声明全局变量
extern icm_param_t icm_data;
extern quater_param_t Q_info;
extern euler_param_t eulerAngle;
extern gyro_param_t GyroOffset;
extern icm_raw_data_t icm_raw_data;

// 函数声明
int icm20602_init(void);
int icm20602_read_raw(int16_t *accel_raw, int16_t *gyro_raw);
void gyroOffsetInit(void);
void icmGetValues(void);
float normalize_quaternion(quater_param_t *q);
void icmAHRSupdate(void);
uint8_t icm20602_get_init_status(void);  // 添加缺失的函数声明

#endif /* __ICM_20602_H */
