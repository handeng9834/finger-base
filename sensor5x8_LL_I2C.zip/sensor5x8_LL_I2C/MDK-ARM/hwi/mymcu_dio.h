#ifndef  __MYMCU_DIO_H
#define  __MYMCU_DIO_H

//-----------------------------------Macro-------------------------------------
/**
  * @brief COL_SEL2 & 1 & 0
  */
#define COL_SEL2_PIN                       		 LL_GPIO_PIN_15
#define COL_SEL2_GPIO_PORT                     GPIOC
#define COL_SEL2_GPIO_CLK_ENABLE()             LL_IOP_GRP1_EnableClock(LL_IOP_GRP1_PERIPH_GPIOC)

#define COL_SEL1_PIN                       		 LL_GPIO_PIN_14
#define COL_SEL1_GPIO_PORT                     GPIOC
#define COL_SEL1_GPIO_CLK_ENABLE()             LL_IOP_GRP1_EnableClock(LL_IOP_GRP1_PERIPH_GPIOC)

#define COL_SEL0_PIN                       		 LL_GPIO_PIN_0
#define COL_SEL0_GPIO_PORT                     GPIOA
#define COL_SEL0_GPIO_CLK_ENABLE()             LL_IOP_GRP1_EnableClock(LL_IOP_GRP1_PERIPH_GPIOA)

#define COL_SEL_EN_PIN                       	 LL_GPIO_PIN_2
#define COL_SEL_EN_GPIO_PORT                   GPIOA
#define COL_SEL_EN_GPIO_CLK_ENABLE()           LL_IOP_GRP1_EnableClock(LL_IOP_GRP1_PERIPH_GPIOA)

#define	Set_COL_SEL2_1												 LL_GPIO_SetOutputPin(COL_SEL2_GPIO_PORT,COL_SEL2_PIN)
#define	Set_COL_SEL2_0												 LL_GPIO_ResetOutputPin(COL_SEL2_GPIO_PORT,COL_SEL2_PIN)

#define	Set_COL_SEL1_1												 LL_GPIO_SetOutputPin(COL_SEL1_GPIO_PORT,COL_SEL1_PIN)
#define	Set_COL_SEL1_0												 LL_GPIO_ResetOutputPin(COL_SEL1_GPIO_PORT,COL_SEL1_PIN)

#define	Set_COL_SEL0_1												 LL_GPIO_SetOutputPin(COL_SEL0_GPIO_PORT,COL_SEL0_PIN)
#define	Set_COL_SEL0_0												 LL_GPIO_ResetOutputPin(COL_SEL0_GPIO_PORT,COL_SEL0_PIN)

#define	Set_COL_SEL_EN_1											 LL_GPIO_SetOutputPin(COL_SEL_EN_GPIO_PORT,COL_SEL_EN_PIN)
#define	Set_COL_SEL_EN_0											 LL_GPIO_ResetOutputPin(COL_SEL_EN_GPIO_PORT,COL_SEL_EN_PIN)									 														 

//-----------------------------------------------------------------------------

//----------------------------------Include------------------------------------
#include "my_type_rdf.h"
#include "my_mcu.h"
//-----------------------------------------------------------------------------

//----------------------------------Declare------------------------------------
//void MyMcu_Init_DI(void);

void MyMcu_Init_DO(void);
void MyMcu_LED_Toggle(void);
//u8   MyMcu_LED0(u8 on);
void MyMcu_Set_Pos_col(uint8_t col);
//-----------------------------------------------------------------------------

#endif
//------------------------------------EOF--------------------------------------








