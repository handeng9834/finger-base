//----------------------------------Include------------------------------------
//#include "my_cfg.h"
#include "my_mcu.h"
#include "my_glbvar.h"
#include	"math.h"
//-----------------------------------------------------------------------------

//-----------------------------------Macro-------------------------------------
#define alpha         0.8
#define _TIM          TIM21
//-----------------------------------------------------------------------------

//--------------------------------Public Func----------------------------------

/**
  * @brief  Configures the timer as a time base.
  * @note   Peripheral configuration is minimal configuration from reset values.
  *         Thus, some useless LL unitary functions calls below are provided as
  *         commented examples - setting is default configuration from reset.
  * @param  None
  * @retval None
  */
	
void MyMcu_Init_Tim21(void)
{
	/* Initial autoreload value */
	static uint32_t InitialAutoreload = 0;

/* Enable the timer peripheral clock */
  LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_TIM21); 
  
  /* Set counter mode */
  /* Reset value is LL_TIM_COUNTERMODE_UP */
  LL_TIM_SetCounterMode(_TIM, LL_TIM_COUNTERMODE_UP);

  /* Set the pre-scaler value to have TIM21 counter clock equal to 10 kHz      */
  /*
  In this example TIM21 input clock TIM2CLK is set to APB2 clock (PCLK2),   
   since APB1 pre-scaler is equal to 1.                                     
      TIM21CLK = PCLK2                                                       
      PCLK12 = HCLK / 2                                                          
      => TIM21CLK = SystemCoreClock / 2 (16 MHz)                                 
  */
  LL_TIM_SetPrescaler(_TIM, __LL_TIM_CALC_PSC(SystemCoreClock, 10000));
  
  /* Set the auto-reload value to have an initial update event frequency of 1000 Hz */
  InitialAutoreload = __LL_TIM_CALC_ARR(SystemCoreClock, LL_TIM_GetPrescaler(_TIM), 1000);
  LL_TIM_SetAutoReload(_TIM, InitialAutoreload);
  
  /* Enable the update interrupt */
  LL_TIM_EnableIT_UPDATE(_TIM);
  
  /* Configure the NVIC to handle _TIM update interrupt */
  NVIC_SetPriority(TIM21_IRQn, 0);
  NVIC_EnableIRQ(TIM21_IRQn);
  
  /* Enable counter */
  LL_TIM_EnableCounter(_TIM);
  
  /* Force update generation */
  LL_TIM_GenerateEvent_UPDATE(_TIM);
}
//-----------------------------------------------------------------------------

//------------------------------------ISR--------------------------------------
/**
* @brief  This function handles TIM21 update interrupt.
* @param  None
* @retval None
*/
void TIM21_IRQHandler(void)
{
	static u8   s_col=0,i;
//  static u16  ad_pre;
//  static uint16_t    ad[NOFCHANEL] = {0};
	/* Check whether update interrupt is pending */
  if(LL_TIM_IsActiveFlag_UPDATE(_TIM) == 1)
  {
    /* Clear the update interrupt flag*/
    LL_TIM_ClearFlag_UPDATE(_TIM);
  }
  
//  /* TIM2 update interrupt processing */
//  TimerUpdate_Callback();
	igu64_tick_ms++;
	
	 for(i=0; i < NOFCHANEL; i++)
    {
//      if(ADC_ConvertedValue[i] > AD_REF_Value)	ad[i] = (ADC_ConvertedValue[i] - AD_REF_Value);
//			else	ad[i] = (AD_REF_Value - ADC_ConvertedValue[i]);
//			ad[i] = alpha*ad[i] + (1-alpha)*gu16_pre[s_row*COL_SIZE + s_col + i*8]; 
//      gu16_pre[s_row*COL_SIZE + s_col + i*COL_SIZE*8] = ad[i];
//			ad[i] = ADC_ConvertedValue[i];
//      gu16_data[s_col + i*COL_SIZE] = ad[i];
			switch(i){
				case 0: ((ADC_ConvertedValue[0] > AD_REF_Value) ? (gu16_data[s_col] 							= ADC_ConvertedValue[0] - AD_REF_Value) : (gu16_data[s_col ] 							= AD_REF_Value - ADC_ConvertedValue[0] )); break;	//����STM32L011��ADת��ͨ��˳��̶�����������Ӳ��һһӳ��
				case 1:	((ADC_ConvertedValue[1] > AD_REF_Value) ? (gu16_data[s_col + COL_SIZE] 		= ADC_ConvertedValue[1] - AD_REF_Value) : (gu16_data[s_col + COL_SIZE ] 		= AD_REF_Value - ADC_ConvertedValue[1] )); break;
				case 2:	((ADC_ConvertedValue[2] > AD_REF_Value) ? (gu16_data[s_col + 2*COL_SIZE]	= ADC_ConvertedValue[2] - AD_REF_Value) : (gu16_data[s_col + 2*COL_SIZE ] 	= AD_REF_Value - ADC_ConvertedValue[2] )); break;
				case 3:	((ADC_ConvertedValue[3] > AD_REF_Value) ? (gu16_data[s_col + 3*COL_SIZE]	= ADC_ConvertedValue[3] - AD_REF_Value) : (gu16_data[s_col + 3*COL_SIZE ] 	= AD_REF_Value - ADC_ConvertedValue[3] )); break;
				case 4:	((ADC_ConvertedValue[4] > AD_REF_Value) ? (gu16_data[s_col + 4*COL_SIZE]	= ADC_ConvertedValue[4] - AD_REF_Value) : (gu16_data[s_col + 4*COL_SIZE ] 	= AD_REF_Value - ADC_ConvertedValue[4] )); break;
				default: break;
			}	
//			gu16_data[s_row*COL_SIZE + s_col + i*8] = ad[i];
    }
		s_col++;
    if(s_col >= COL_SIZE) s_col = 0; 
    MyMcu_Set_Pos_col(s_col);
//		 MyMcu_Set_Pos_col(0);
	
}
//------------------------------------EOF--------------------------------------





