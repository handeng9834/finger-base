//----------------------------------Include------------------------------------
#include  <stdio.h>
#include "my_type_rdf.h"
#include "stm32l0xx_ll_i2c.h"
#include "mymcu_i2c.h"
#include "my_glbvar.h"
#include "mymcu_VCNL36825T.h"
#include "stm32l0xx_ll_utils.h"

//Global Variables
u16 SEL_Offset;
//Variables for Offset Value
u16 CalibValue = 0;
u16 OffsetValue = 0;
u8 AverageCount = 10; //Change the average count to the needed number of offset measurement


void INIT_VCNL36825T(void)
{
	u8 reg_RDdata_tmp[2];
	u8 reg_WRdata_tmp[2];

  /* Reset Sensor to default value */
	i2c_WriteWord(0x0001, SLAVE_VCNL36825T_Addr,VCNL36825T_PS_CONF1_L);	
	i2c_WriteWord(0x0001, SLAVE_VCNL36825T_Addr,VCNL36825T_PS_CONF2_L);	
	i2c_WriteWord(0x0000, SLAVE_VCNL36825T_Addr,VCNL36825T_PS_CONF3_L);
	i2c_WriteWord(0x0000, SLAVE_VCNL36825T_Addr,VCNL36825T_PS_THDL);
	i2c_WriteWord(0x0000, SLAVE_VCNL36825T_Addr,VCNL36825T_PS_THDH);	
	i2c_WriteWord(0x0000, SLAVE_VCNL36825T_Addr,VCNL36825T_PS_CANC);	
	i2c_WriteWord(0x0000, SLAVE_VCNL36825T_Addr,VCNL36825T_PS_CONF4_L);

	/****************************************************************************/
	/***********************Setting Up The Mode & Variables**********************/

	/* Choose a desired proximity mode */
	/*
	 * SEL_PS_Mode - Select the proximity mode:
	 * 0 - Turn Off proximity mode/shutdown
	 * 1 - Auto/Self-Timed Mode
	 * 2 - Active Force Mode/Continuous Forced Mode
	 * 3 - Low Power Mode
	 * 4 - Auto Calibration Mode
	 *
	 */
	//1.)Initialization
	//Switch On the sensor, set PS_ON = 1;
	i2c_ReadBytes(&(reg_RDdata_tmp[0]), SLAVE_VCNL36825T_Addr, VCNL36825T_PS_CONF1_L, 2);  
	reg_WRdata_tmp[0] = (reg_RDdata_tmp[0] &~(VCNL36825T_PS_ON_EN|VCNL36825T_PS_ON_DIS)) | VCNL36825T_PS_ON_EN;
	reg_WRdata_tmp[1] = reg_RDdata_tmp[1];
	i2c_WriteWord((reg_WRdata_tmp[1]<<8 |  reg_WRdata_tmp[0]), SLAVE_VCNL36825T_Addr,VCNL36825T_PS_CONF1_L);	
	// set PS_CAL = 1
	i2c_ReadBytes(&(reg_RDdata_tmp[0]), SLAVE_VCNL36825T_Addr, VCNL36825T_PS_CONF1_L, 2);  
	reg_WRdata_tmp[0] = (reg_RDdata_tmp[0] &~(VCNL36825T_PS_CAL_EN|VCNL36825T_PS_CAL_DIS)) | VCNL36825T_PS_CAL_EN;
	reg_WRdata_tmp[1] = (reg_RDdata_tmp[1] &~(VCNL36825T_PS_LDO_EN))|VCNL36825T_PS_LDO_EN;
	i2c_WriteWord((reg_WRdata_tmp[1]<<8 |  reg_WRdata_tmp[0]), SLAVE_VCNL36825T_Addr,VCNL36825T_PS_CONF1_L);
	// Ensure that PS_ST = 1 before setting up PS_AF = Auto
	i2c_ReadBytes(&(reg_RDdata_tmp[0]), SLAVE_VCNL36825T_Addr, VCNL36825T_PS_CONF2_L, 2);  
	reg_WRdata_tmp[0] = (reg_RDdata_tmp[0] &~(VCNL36825T_PS_ST_START|VCNL36825T_PS_ST_STOP)) | VCNL36825T_PS_ST_STOP;
	reg_WRdata_tmp[1] = reg_RDdata_tmp[1];
	i2c_WriteWord((reg_WRdata_tmp[1]<<8 |  reg_WRdata_tmp[0]), SLAVE_VCNL36825T_Addr,VCNL36825T_PS_CONF2_L);
	
	i2c_ReadBytes(&(reg_RDdata_tmp[0]), SLAVE_VCNL36825T_Addr, VCNL36825T_PS_CONF3_L, 2);  
	reg_WRdata_tmp[0] = (reg_RDdata_tmp[0] &~(VCNL36825T_PS_CAL_AUTO)) | VCNL36825T_PS_CAL_AUTO;
	reg_WRdata_tmp[1] = reg_RDdata_tmp[1];
	i2c_WriteWord((reg_WRdata_tmp[1]<<8 |  reg_WRdata_tmp[0]), SLAVE_VCNL36825T_Addr,VCNL36825T_PS_CONF3_L);
	
	//2.) Setting up PS
	//PS_CONF1_L and PS_CONF1_H
	//have been set up during the initialization
	
	//PS_CONF2_L
	//Set the sample Period of measurement
	i2c_ReadBytes(&(reg_RDdata_tmp[0]), SLAVE_VCNL36825T_Addr, VCNL36825T_PS_CONF2_L, 2);  
	reg_WRdata_tmp[0] = (reg_RDdata_tmp[0] &~( VCNL36825T_PS_PERIOD_10ms|VCNL36825T_PS_PERIOD_20ms|VCNL36825T_PS_PERIOD_40ms|VCNL36825T_PS_PERIOD_80ms)) | VCNL36825T_PS_PERIOD_10ms;
	reg_WRdata_tmp[1] = reg_RDdata_tmp[1];
	i2c_WriteWord((reg_WRdata_tmp[1]<<8 |  reg_WRdata_tmp[0]), SLAVE_VCNL36825T_Addr,VCNL36825T_PS_CONF2_L);
	
	//Set the Persistence
	i2c_ReadBytes(&(reg_RDdata_tmp[0]), SLAVE_VCNL36825T_Addr, VCNL36825T_PS_CONF2_L, 2);  
	reg_WRdata_tmp[0] = (reg_RDdata_tmp[0] &~( VCNL36825T_PS_PERS_1|VCNL36825T_PS_PERS_2|VCNL36825T_PS_PERS_3|VCNL36825T_PS_PERS_4)) | VCNL36825T_PS_PERS_1;
	reg_WRdata_tmp[1] = reg_RDdata_tmp[1];
	i2c_WriteWord((reg_WRdata_tmp[1]<<8 |  reg_WRdata_tmp[0]), SLAVE_VCNL36825T_Addr,VCNL36825T_PS_CONF2_L);
	//Set the Interrupt Mode
	i2c_ReadBytes(&(reg_RDdata_tmp[0]), SLAVE_VCNL36825T_Addr, VCNL36825T_PS_CONF2_L, 2);  
	reg_WRdata_tmp[0] = (reg_RDdata_tmp[0] &~( VCNL36825T_PS_INT_DIS|VCNL36825T_PS_INT_LOGIC|VCNL36825T_PS_INT_FIRST_HIGH|VCNL36825T_PS_INT_EN)) | VCNL36825T_PS_INT_EN;
	reg_WRdata_tmp[1] = reg_RDdata_tmp[1];
	i2c_WriteWord((reg_WRdata_tmp[1]<<8 |  reg_WRdata_tmp[0]), SLAVE_VCNL36825T_Addr,VCNL36825T_PS_CONF2_L);
	//Enable/Disable Smart Persistence
	i2c_ReadBytes(&(reg_RDdata_tmp[0]), SLAVE_VCNL36825T_Addr, VCNL36825T_PS_CONF2_L, 2);  
	reg_WRdata_tmp[0] = (reg_RDdata_tmp[0] &~( VCNL36825T_PS_SMART_PERS_DIS|VCNL36825T_PS_SMART_PERS_EN)) | VCNL36825T_PS_SMART_PERS_DIS;
	reg_WRdata_tmp[1] = reg_RDdata_tmp[1];
	i2c_WriteWord((reg_WRdata_tmp[1]<<8 |  reg_WRdata_tmp[0]), SLAVE_VCNL36825T_Addr,VCNL36825T_PS_CONF2_L);
	//PS_ST will be set when starting the measurement
	
	//PS_CONF2_H
	//Set the Integration Time
	i2c_ReadBytes(&(reg_RDdata_tmp[0]), SLAVE_VCNL36825T_Addr, VCNL36825T_PS_CONF2_H, 2);
  reg_WRdata_tmp[0] = reg_RDdata_tmp[0];
	reg_WRdata_tmp[1] = (reg_RDdata_tmp[1] &~( VCNL36825T_PS_IT_1T|VCNL36825T_PS_IT_2T|VCNL36825T_PS_IT_4T|VCNL36825T_PS_IT_8T)) | VCNL36825T_PS_IT_1T;
	i2c_WriteWord((reg_WRdata_tmp[1]<<8 |  reg_WRdata_tmp[0]), SLAVE_VCNL36825T_Addr,VCNL36825T_PS_CONF2_H);
	//Set the MPS
	i2c_ReadBytes(&(reg_RDdata_tmp[0]), SLAVE_VCNL36825T_Addr, VCNL36825T_PS_CONF2_H, 2);
  reg_WRdata_tmp[0] = reg_RDdata_tmp[0];
	reg_WRdata_tmp[1] = (reg_RDdata_tmp[1] &~( VCNL36825T_PS_MPS_1|VCNL36825T_PS_MPS_2|VCNL36825T_PS_MPS_4|VCNL36825T_PS_MPS_8)) | VCNL36825T_PS_MPS_1;
	i2c_WriteWord((reg_WRdata_tmp[1]<<8 |  reg_WRdata_tmp[0]), SLAVE_VCNL36825T_Addr,VCNL36825T_PS_CONF2_H);
	//Set the IT Bank
	i2c_ReadBytes(&(reg_RDdata_tmp[0]), SLAVE_VCNL36825T_Addr, VCNL36825T_PS_CONF2_H, 2);
  reg_WRdata_tmp[0] = reg_RDdata_tmp[0];
	reg_WRdata_tmp[1] = (reg_RDdata_tmp[1] &~( VCNL36825T_PS_ITB_25|VCNL36825T_PS_ITB_50)) | VCNL36825T_PS_ITB_50;
	i2c_WriteWord((reg_WRdata_tmp[1]<<8 |  reg_WRdata_tmp[0]), SLAVE_VCNL36825T_Addr,VCNL36825T_PS_CONF2_H);
	//Enable/Disable the High Gain setting
	i2c_ReadBytes(&(reg_RDdata_tmp[0]), SLAVE_VCNL36825T_Addr, VCNL36825T_PS_CONF2_H, 2);
  reg_WRdata_tmp[0] = reg_RDdata_tmp[0];
	reg_WRdata_tmp[1] = (reg_RDdata_tmp[1] &~( VCNL36825T_PS_HG_DIS|VCNL36825T_PS_HG_EN)) | VCNL36825T_PS_HG_DIS;
	i2c_WriteWord((reg_WRdata_tmp[1]<<8 |  reg_WRdata_tmp[0]), SLAVE_VCNL36825T_Addr,VCNL36825T_PS_CONF2_H);
	//PS_CONF3_L
	//Set the PS sunlight protect
	i2c_ReadBytes(&(reg_RDdata_tmp[0]), SLAVE_VCNL36825T_Addr, VCNL36825T_PS_CONF3_L, 2);
  reg_WRdata_tmp[0] = (reg_RDdata_tmp[0] &~( VCNL36825T_PS_SP_INT_DIS|VCNL36825T_PS_SP_INT_EN)) | VCNL36825T_PS_SP_INT_EN;
	reg_WRdata_tmp[1] = reg_RDdata_tmp[1];
	i2c_WriteWord((reg_WRdata_tmp[1]<<8 |  reg_WRdata_tmp[0]), SLAVE_VCNL36825T_Addr,VCNL36825T_PS_CONF3_L);
	//Set number of detect cycle after trigger
	i2c_ReadBytes(&(reg_RDdata_tmp[0]), SLAVE_VCNL36825T_Addr, VCNL36825T_PS_CONF3_L, 2);
  reg_WRdata_tmp[0] = (reg_RDdata_tmp[0] &~( VCNL36825T_PS_FORCENUM_1|VCNL36825T_PS_FORCENUM_2)) | VCNL36825T_PS_FORCENUM_1;
	reg_WRdata_tmp[1] = reg_RDdata_tmp[1];
	i2c_WriteWord((reg_WRdata_tmp[1]<<8 |  reg_WRdata_tmp[0]), SLAVE_VCNL36825T_Addr,VCNL36825T_PS_CONF3_L);
	//PS_AF has been set during initialization and PS_TRIG needs to be set before doing proximity measurement

	//PS_CONF3_H
	//Set the sunlight cancellation
	i2c_ReadBytes(&(reg_RDdata_tmp[0]), SLAVE_VCNL36825T_Addr, VCNL36825T_PS_CONF3_H, 2);
  reg_WRdata_tmp[0] = reg_RDdata_tmp[0];
	reg_WRdata_tmp[1] = (reg_RDdata_tmp[1] &~( VCNL36825T_PS_SC_EN|VCNL36825T_PS_SC_DIS)) | VCNL36825T_PS_SC_EN;
	i2c_WriteWord((reg_WRdata_tmp[1]<<8 |  reg_WRdata_tmp[0]), SLAVE_VCNL36825T_Addr,VCNL36825T_PS_CONF3_H);
	//Set the Sensor output Bit Size
	i2c_ReadBytes(&(reg_RDdata_tmp[0]), SLAVE_VCNL36825T_Addr, VCNL36825T_PS_CONF3_H, 2);
  reg_WRdata_tmp[0] = reg_RDdata_tmp[0];
	reg_WRdata_tmp[1] = (reg_RDdata_tmp[1] &~( VCNL36825T_PS_HD_12Bits|VCNL36825T_PS_HD_16Bits)) | VCNL36825T_PS_HD_12Bits;
	i2c_WriteWord((reg_WRdata_tmp[1]<<8 |  reg_WRdata_tmp[0]), SLAVE_VCNL36825T_Addr,VCNL36825T_PS_CONF3_H);
	//Set the VCSEL current
	i2c_ReadBytes(&(reg_RDdata_tmp[0]), SLAVE_VCNL36825T_Addr, VCNL36825T_PS_CONF3_H, 2);
  reg_WRdata_tmp[0] = reg_RDdata_tmp[0];
	reg_WRdata_tmp[1] = (reg_RDdata_tmp[1] &~( VCNL36825T_I_VCSEL_10mA|VCNL36825T_I_VCSEL_12mA|VCNL36825T_I_VCSEL_14mA|VCNL36825T_I_VCSEL_16mA|VCNL36825T_I_VCSEL_18mA|VCNL36825T_I_VCSEL_20mA)) | VCNL36825T_I_VCSEL_20mA;
	i2c_WriteWord((reg_WRdata_tmp[1]<<8 |  reg_WRdata_tmp[0]), SLAVE_VCNL36825T_Addr,VCNL36825T_PS_CONF3_H);
	
	//PS_CONF4_H
  //Disable Low Power Mode
	i2c_ReadBytes(&(reg_RDdata_tmp[0]), SLAVE_VCNL36825T_Addr, VCNL36825T_PS_CONF4_H, 2);
  reg_WRdata_tmp[0] = reg_RDdata_tmp[0];
	reg_WRdata_tmp[1] = (reg_RDdata_tmp[1] &~( VCNL36825T_PS_LPEN_DIS|VCNL36825T_PS_LPEN_EN)) | VCNL36825T_PS_LPEN_DIS;
	i2c_WriteWord((reg_WRdata_tmp[1]<<8 |  reg_WRdata_tmp[0]), SLAVE_VCNL36825T_Addr,VCNL36825T_PS_CONF4_H);

    //3). Starting the PS
	i2c_ReadBytes(&(reg_RDdata_tmp[0]), SLAVE_VCNL36825T_Addr, VCNL36825T_PS_CONF2_L, 2);
  reg_WRdata_tmp[0] = (reg_RDdata_tmp[0] &~( VCNL36825T_PS_ST_START|VCNL36825T_PS_ST_STOP)) | VCNL36825T_PS_ST_START;
	reg_WRdata_tmp[1] = reg_RDdata_tmp[1];
	i2c_WriteWord((reg_WRdata_tmp[1]<<8 |  reg_WRdata_tmp[0]), SLAVE_VCNL36825T_Addr,VCNL36825T_PS_CONF2_L);
	
	i2c_ReadBytes(&(reg_RDdata_tmp[0]), SLAVE_VCNL36825T_Addr, VCNL36825T_PS_CONF3_L, 2);
  reg_WRdata_tmp[0] = (reg_RDdata_tmp[0] &~( VCNL36825T_PS_CAL_AUTO)) | VCNL36825T_PS_CAL_AUTO;
	reg_WRdata_tmp[1] = reg_RDdata_tmp[1];
	i2c_WriteWord((reg_WRdata_tmp[1]<<8 |  reg_WRdata_tmp[0]), SLAVE_VCNL36825T_Addr,VCNL36825T_PS_CONF3_L);

    //4.) Threshold Setting and Offset Measurement
	for(int i=0;i<AverageCount;i++)
	{
		//Delay of 10 ms needs to be changed depending on the API of the ��-controller of use
		LL_mDelay(10);
		i2c_ReadBytes(&(reg_RDdata_tmp[0]), SLAVE_VCNL36825T_Addr, VCNL36825T_PS_DATA, 2);
		CalibValue += (reg_RDdata_tmp[1] << 8 | reg_RDdata_tmp[0]);
		//Delay of 10 ms needs to be changed depending on the API of the ��-controller of use
		LL_mDelay(10);
	}

	//Calculate the average of the offset measurement
	CalibValue /= AverageCount;

	//Perform Offset Measurement
	if(SEL_Offset == 0) OffsetValue = 0;
	if(SEL_Offset == 1) OffsetValue = CalibValue;
	//Set Cancellation register to eliminate offset
  reg_WRdata_tmp[0] = OffsetValue;
	reg_WRdata_tmp[1] = OffsetValue >> 8;
	i2c_WriteWord((reg_WRdata_tmp[1]<<8 |  reg_WRdata_tmp[0]), SLAVE_VCNL36825T_Addr,VCNL36825T_PS_CANC);
	//Set Low Threshold
	i2c_WriteWord(1000, SLAVE_VCNL36825T_Addr,VCNL36825T_PS_THDL);
	i2c_ReadBytes(&(reg_RDdata_tmp[0]), SLAVE_VCNL36825T_Addr, VCNL36825T_PS_THDL, 2);
	//Set High Threshold
	i2c_WriteWord(1500, SLAVE_VCNL36825T_Addr,VCNL36825T_PS_THDH);
	i2c_ReadBytes(&(reg_RDdata_tmp[0]), SLAVE_VCNL36825T_Addr, VCNL36825T_PS_THDH, 2);

  //Delay of 10 ms needs to be changed depending on the API of the ��-controller of use
  LL_mDelay(10);
  //Clear initial interrupt
	i2c_ReadBytes(&(reg_RDdata_tmp[0]), SLAVE_VCNL36825T_Addr, VCNL36825T_PS_INT_FLAG, 2);
	LL_mDelay(1000);

	/***************************End of Implementation****************************/
    /****************************************************************************/
}
