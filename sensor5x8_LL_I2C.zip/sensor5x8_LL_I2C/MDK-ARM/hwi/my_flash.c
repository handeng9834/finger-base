//----------------------------------Include------------------------------------
#include  <string.h>
#include  <stdlib.h>
#include  "my_type_rdf.h"
#include  "my_glbvar.h"
#include  "my_flash.h"
#include	"stm32l011xx.h"
//-----------------------------------------------------------------------------

//-----------------------------------Macro-------------------------------------

#define EEPROM_BASE_ADDR	0x08080000	
#define EEPROM_BYTE_SIZE	0x01FF

#define PEKEY1	0x89ABCDEF		//FLASH_PEKEYR
#define PEKEY2	0x02030405		//FLASH_PEKEYR





#define EN_INT          __enable_irq();     //ϵͳ��ȫ���ж�   
#define DIS_INT         __disable_irq();    //ϵͳ��ȫ���ж� 

//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------

//------------------------------------Type-------------------------------------

//-----------------------------------------------------------------------------

//---------------------------------Static Var----------------------------------
//-----------------------------------------------------------------------------

//--------------------------------Static Func----------------------------------

//-----------------------------------------------------------------------------

//--------------------------------Public Func----------------------------------
/*------------------------------------------------------------
 Func: EEPROM���ݰ��ֽڶ���
 Note:
-------------------------------------------------------------*/
void EEPROM_ReadBytes(u16 Addr,u8 *Buffer,u16 Length)
{
	u8 *wAddr;
	wAddr=(u8 *)(EEPROM_BASE_ADDR+Addr);
	while(Length--){
		*Buffer++=*wAddr++;
	}	
}


/*------------------------------------------------------------
 Func: EEPROM���ݰ��ֽ�д��
 Note:
-------------------------------------------------------------*/
void EEPROM_WriteBytes(u16 Addr,u8 *Buffer,u16 Length)
{
	u8 *wAddr;
	wAddr=(u8 *)(EEPROM_BASE_ADDR+Addr);
	DIS_INT
	FLASH->PEKEYR=PEKEY1;				//unlock
	FLASH->PEKEYR=PEKEY2;
	while(FLASH->PECR&FLASH_PECR_PELOCK);
//	FLASH->PECR|=FLASH_PECR_FTDW;		//not fast write
	while(Length--){
		*wAddr++=*Buffer++;
		while(FLASH->SR&FLASH_SR_BSY);
	}
	FLASH->PECR|=FLASH_PECR_PELOCK;
	EN_INT
}


//-------------------------------------EOF-------------------------------------




