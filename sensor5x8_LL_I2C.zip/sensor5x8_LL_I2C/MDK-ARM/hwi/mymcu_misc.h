#ifndef  __MYMCU_MISC_H
#define  __MYMCU_MISC_H

//-----------------------------------Macro-------------------------------------
//-----------------------------------------------------------------------------

//----------------------------------Include------------------------------------
#include "my_type_rdf.h"
//-----------------------------------------------------------------------------

//----------------------------------Declare------------------------------------
void MyMcu_SysClock(void);
//void MyMcu_PriGrpCfg(void);
//  
//void MyMcu_Int_Disable(void);
//void MyMcu_Int_Enable(void) ;
//void MyMcu_Nop(void)        ;
//void MyMcu_Reset(void)      ;

//u32  MyMcu_GetSysClk(void)  ;
//u32  MyMcu_GetClk_AHB(void) ;
//u32  MyMcu_GetClk_ADC(void) ;

//u32  MyMcu_GetClk_APB1(void);
//u32  MyMcu_GetClk_APB2(void);
//u32  MyMcu_GetClk_APB1_TIM(void);
//u32  MyMcu_GetClk_APB2_TIM(void);

//void MyMcu_Disable_Jtag(void);
//-----------------------------------------------------------------------------

#endif
//------------------------------------EOF--------------------------------------








