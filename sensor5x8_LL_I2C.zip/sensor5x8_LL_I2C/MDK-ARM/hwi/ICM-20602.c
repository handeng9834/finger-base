#include <stdint.h>
#include <stdbool.h>
#include "mymcu_i2c.h"
#include <math.h>
#include "ICM-20602.h"
#include "custom_delay.h"

// 定义全局变量
icm_param_t icm_data = {0};  // ICM20602采集的六轴数值
quater_param_t Q_info = {1, 0, 0, 0};  // 四元数初始化
euler_param_t eulerAngle = {0};  // 欧拉角
gyro_param_t GyroOffset = {0};  // 陀螺仪校准值
icm_raw_data_t icm_raw_data = {0};  // 原始数据

// 添加寄存器原始值存储结构
typedef struct {
    uint8_t accel_xh;  // 加速度计X轴高8位
    uint8_t accel_xl;  // 加速度计X轴低8位
    uint8_t accel_yh;  // 加速度计Y轴高8位
    uint8_t accel_yl;  // 加速度计Y轴低8位
    uint8_t accel_zh;  // 加速度计Z轴高8位
    uint8_t accel_zl;  // 加速度计Z轴低8位
    uint8_t gyro_xh;   // 陀螺仪X轴高8位
    uint8_t gyro_xl;   // 陀螺仪X轴低8位
    uint8_t gyro_yh;   // 陀螺仪Y轴高8位
    uint8_t gyro_yl;   // 陀螺仪Y轴低8位
    uint8_t gyro_zh;   // 陀螺仪Z轴高8位
    uint8_t gyro_zl;   // 陀螺仪Z轴低8位
} icm_reg_raw_t;

// 定义全局变量存储寄存器原始值
icm_reg_raw_t icm_reg_raw = {0};

// 定义ICM-20602的I2C地址，SA0=1时为0x69
#define ICM20602_I2C_ADDR 0x69
#define delta_T     0.001f  // 采样周期1ms，频率1kHz
#define PI          3.1415926f
#define WHO_AM_I_ID 0x12    // 设备ID
#define I2C_WRITE   0
#define I2C_READ    1
#define RAD_TO_DEG  (180.0f/PI)

// 定义超时时间
#define I2C_TIMEOUT 1000  // 1ms超时
#define INIT_TIMEOUT 100  // 100ms超时

float I_ex = 0, I_ey = 0, I_ez = 0;  // 误差积分
float icm_kp = 0.17;  // 加速度计的收敛速率比例增益 
float icm_ki = 0.004;  // 陀螺仪收敛速率的积分增益

// 添加初始化状态标志
static uint8_t icm_init_status = 0;

// 修改校准参数
#define CALIBRATION_SAMPLES 200  // 采样次数
#define CALIBRATION_INTERVAL 10  // 采样间隔(ms)
#define MAX_ACCEL_DEVIATION 0.2f // 增加加速度允许偏差范围
#define MAX_GYRO_DEVIATION 0.5f  // 陀螺仪最大允许偏差(dps)

// 加速度计校准值
typedef struct {
    float offset_x;
    float offset_y;
    float offset_z;
    float scale_x;
    float scale_y;
    float scale_z;
} accel_calibration_t;

static accel_calibration_t accel_cal = {
    .offset_x = 0.0f,
    .offset_y = 0.0f,
    .offset_z = 0.0f,
    .scale_x = 1.0f,
    .scale_y = 1.0f,
    .scale_z = 1.0f
};

// 数据有效性检查函数
static bool is_valid_accel_data(float ax, float ay, float az) {
    // 检查加速度大小是否接近1g，增加允许范围
    float accel_magnitude = sqrtf(ax*ax + ay*ay + az*az);
    return (fabsf(accel_magnitude - 1.0f) < MAX_ACCEL_DEVIATION);
}

static bool is_valid_gyro_data(float gx, float gy, float gz) {
    // 检查角速度是否在合理范围内
    return (fabsf(gx) < MAX_GYRO_DEVIATION && 
            fabsf(gy) < MAX_GYRO_DEVIATION && 
            fabsf(gz) < MAX_GYRO_DEVIATION);
}

// 初始化ICM-20602函数
int icm20602_init() {
    uint8_t retry = 0;
    uint8_t id = 0;
    uint32_t timeout;
    

    
    // 复位设备
    while(retry < 3) {
        if(icm20602_i2c_write(0x6B, 0x80)) {

            break;
        }
        retry++;
        Delay_us(1000);  // 使用更短的延时
    }
    if(retry >= 3) {

        icm_init_status = 0;
        return 0;
    }
    
    Delay_ms(50); // 减少复位等待时间
    
    // 设置时钟源为自动选择，唤醒设备
    retry = 0;
    while(retry < 3) {
        if(icm20602_i2c_write(0x6B, 0x01)) {

            break;
        }
        retry++;
        Delay_us(1000);
    }
    if(retry >= 3) {

        icm_init_status = 0;
        return 0;
    }
    
    // 配置陀螺仪满量程范围为±250dps（FS_SEL=00）
    retry = 0;
    while(retry < 3) {
        if(icm20602_i2c_write(0x1B, 0x00)) {

            break;
        }
        retry++;
        Delay_us(1000);
    }
    if(retry >= 3) {

        icm_init_status = 0;
        return 0;
    }
    
    // 配置加速度计满量程范围为±2g（ACCEL_FS_SEL=00）
    retry = 0;
    while(retry < 3) {
        if(icm20602_i2c_write(0x1C, 0x00)) {

            break;
        }
        retry++;
        Delay_us(1000);
    }
    if(retry >= 3) {

        icm_init_status = 0;
        return 0;
    }
    
    // 配置采样率分频器（SMPLRT_DIV=7，采样率=1kHz/(1+7)=125Hz）
    retry = 0;
    while(retry < 3) {
        if(icm20602_i2c_write(0x19, 0x07)) {

            break;
        }
        retry++;
        Delay_us(1000);
    }
    if(retry >= 3) {

        icm_init_status = 0;
        return 0;
    }
    
    // 配置低通滤波器（DLPF_CFG=3，带宽41Hz）
    retry = 0;
    while(retry < 3) {
        if(icm20602_i2c_write(0x1A, 0x03)) {
 
            break;
        }
        retry++;
        Delay_us(1000);
    }
    if(retry >= 3) {
 
        icm_init_status = 0;
        return 0;
    }
    
    // 校验设备ID
    timeout = INIT_TIMEOUT;
    while(timeout--) {
        id = icm20602_i2c_read(WHO_AM_I);
        if(id == WHO_AM_I_ID) {

            icm_init_status = 1;
            return 1;
        }
        Delay_us(1000);
    }
    

    icm_init_status = 0;
    return 0;
}

// 读取加速度计和陀螺仪原始数据
int icm20602_read_raw(int16_t *accel_raw, int16_t *gyro_raw) {
    uint32_t timeout = I2C_TIMEOUT;
    
    // 检查设备是否就绪
    uint8_t pwr_mgmt = icm20602_i2c_read(PWR_MGMT_1);
    if (pwr_mgmt & 0x40) {  // 检查DEVICE_RESET位

        return 0;
    }
    if (pwr_mgmt & 0x20) {  // 检查SLEEP位

        return 0;
    }
    
    while(timeout--) {
        // 直接读取加速度计寄存器
        if(accel_raw) {
            icm_reg_raw.accel_xh = icm20602_i2c_read(0x3B);
            icm_reg_raw.accel_xl = icm20602_i2c_read(0x3C);
            icm_reg_raw.accel_yh = icm20602_i2c_read(0x3D);
            icm_reg_raw.accel_yl = icm20602_i2c_read(0x3E);
            icm_reg_raw.accel_zh = icm20602_i2c_read(0x3F);
            icm_reg_raw.accel_zl = icm20602_i2c_read(0x40);
            
            // 组合数据
            accel_raw[0] = (int16_t)((icm_reg_raw.accel_xh << 8) | icm_reg_raw.accel_xl);
            accel_raw[1] = (int16_t)((icm_reg_raw.accel_yh << 8) | icm_reg_raw.accel_yl);
            accel_raw[2] = (int16_t)((icm_reg_raw.accel_zh << 8) | icm_reg_raw.accel_zl);
        }
        
        // 直接读取陀螺仪寄存器
        if(gyro_raw) {
            icm_reg_raw.gyro_xh = icm20602_i2c_read(0x43);
            icm_reg_raw.gyro_xl = icm20602_i2c_read(0x44);
            icm_reg_raw.gyro_yh = icm20602_i2c_read(0x45);
            icm_reg_raw.gyro_yl = icm20602_i2c_read(0x46);
            icm_reg_raw.gyro_zh = icm20602_i2c_read(0x47);
            icm_reg_raw.gyro_zl = icm20602_i2c_read(0x48);
            
            // 组合数据
            gyro_raw[0] = (int16_t)((icm_reg_raw.gyro_xh << 8) | icm_reg_raw.gyro_xl);
            gyro_raw[1] = (int16_t)((icm_reg_raw.gyro_yh << 8) | icm_reg_raw.gyro_yl);
            gyro_raw[2] = (int16_t)((icm_reg_raw.gyro_zh << 8) | icm_reg_raw.gyro_zl);
        }
        

        
        return 1;
    }
    

    return 0;
}

// 获取初始化状态
uint8_t icm20602_get_init_status(void) {
    return icm_init_status;
}

// 优化的陀螺仪和加速度计校准函数
void gyroOffsetInit(void) {
    int16_t gyro_raw[3] = {0};
    float accel_sum[3] = {0};
    float gyro_sum[3] = {0};
    uint16_t valid_samples = 0;
    

    // 等待传感器稳定
    Delay_ms(1000);
    
    for (uint16_t i = 0; i < CALIBRATION_SAMPLES; ++i) {
        if (icm20602_read_raw(NULL, gyro_raw)) {
            // 获取加速度数据
            float ax = (float)icm_raw_data.acc_x / 16384.0f;
            float ay = (float)icm_raw_data.acc_y / 16384.0f;
            float az = (float)icm_raw_data.acc_z / 16384.0f;
            
            // 获取陀螺仪数据
            float gx = (float)gyro_raw[0] * PI / 180.0f / 131.0f;
            float gy = (float)gyro_raw[1] * PI / 180.0f / 131.0f;
            float gz = (float)gyro_raw[2] * PI / 180.0f / 131.0f;
            
            // 检查数据有效性
            if (is_valid_accel_data(ax, ay, az) && is_valid_gyro_data(gx, gy, gz)) {
                // 累加有效数据
                accel_sum[0] += ax;
                accel_sum[1] += ay;
                accel_sum[2] += az;
                
                gyro_sum[0] += gx;
                gyro_sum[1] += gy;
                gyro_sum[2] += gz;
                
                valid_samples++;
            }
        }
        Delay_ms(CALIBRATION_INTERVAL);
    }
    
    if (valid_samples > 0) {
        // 计算平均值
        float accel_avg[3] = {
            accel_sum[0] / valid_samples,
            accel_sum[1] / valid_samples,
            accel_sum[2] / valid_samples
        };
        
        float gyro_avg[3] = {
            gyro_sum[0] / valid_samples,
            gyro_sum[1] / valid_samples,
            gyro_sum[2] / valid_samples
        };
        
        // 更新陀螺仪零偏
        GyroOffset.Xdata = (int16_t)(gyro_avg[0] * 131.0f * 180.0f / PI);
        GyroOffset.Ydata = (int16_t)(gyro_avg[1] * 131.0f * 180.0f / PI);
        GyroOffset.Zdata = (int16_t)(gyro_avg[2] * 131.0f * 180.0f / PI);
        
        // 计算加速度计校准参数
        float accel_magnitude = sqrtf(accel_avg[0]*accel_avg[0] + 
                                    accel_avg[1]*accel_avg[1] + 
                                    accel_avg[2]*accel_avg[2]);
        
        // 只计算偏移量，不修改比例因子
        accel_cal.offset_x = accel_avg[0];
        accel_cal.offset_y = accel_avg[1];
        accel_cal.offset_z = accel_avg[2] - 1.0f; // 减去重力加速度
        


    } else {

    }
}

// 修改数据获取函数，简化加速度处理
void icmGetValues(void) {
    int16_t accel_raw[3], gyro_raw[3];
    static uint8_t error_count = 0;
    
    if (!icm20602_read_raw(accel_raw, gyro_raw)) {
        error_count++;
        if(error_count > 10) {

            icm20602_init();
            error_count = 0;
        }
        return;
    }
    error_count = 0;

    // 保存原始数据
    icm_raw_data.acc_x = accel_raw[0];
    icm_raw_data.acc_y = accel_raw[1];
    icm_raw_data.acc_z = accel_raw[2];
    icm_raw_data.gyro_x = gyro_raw[0];
    icm_raw_data.gyro_y = gyro_raw[1];



    icm_raw_data.gyro_z = gyro_raw[2];

    // 加速度计数据处理
    float ax = (float)accel_raw[0] / 16384.0f;
    float ay = (float)accel_raw[1] / 16384.0f;
    float az = (float)accel_raw[2] / 16384.0f;
    
    // 只应用偏移校准，不应用比例因子
    icm_data.acc_x = ax - accel_cal.offset_x;
    icm_data.acc_y = ay - accel_cal.offset_y;
    icm_data.acc_z = az - accel_cal.offset_z;

    // 陀螺仪数据处理
    icm_data.gyro_x = (float)(gyro_raw[0] - GyroOffset.Xdata) * PI / 180.0f / 131.0f;
    icm_data.gyro_y = (float)(gyro_raw[1] - GyroOffset.Ydata) * PI / 180.0f / 131.0f;
    icm_data.gyro_z = (float)(gyro_raw[2] - GyroOffset.Zdata) * PI / 180.0f / 131.0f;
    

}

// 单位四元数归一化函数（使用标准数学库版本）
float normalize_quaternion(quater_param_t *q) {
    float norm = sqrtf(q->q0*q->q0 + q->q1*q->q1 + q->q2*q->q2 + q->q3*q->q3);
    if (norm == 0) return 0; // 避免除零
    q->q0 /= norm;
    q->q1 /= norm;
    q->q2 /= norm;
    q->q3 /= norm;
    return norm;
}


// 姿态解算（互补滤波 + 四元数）
void icmAHRSupdate(void) {
    float gx = icm_data.gyro_x, gy = icm_data.gyro_y, gz = icm_data.gyro_z;
    float ax = icm_data.acc_x, ay = icm_data.acc_y, az = icm_data.acc_z;
    float q0 = Q_info.q0, q1 = Q_info.q1, q2 = Q_info.q2, q3 = Q_info.q3;
    float halfT = 0.5f * delta_T;
    float vx, vy, vz, ex, ey, ez;
    float norm;

    // 跳过无效加速度数据
    if (ax == 0 && ay == 0 && az == 0) {

        return;
    }

    // 计算重力在载体坐标系的分量
    vx = 2 * (q1*q3 - q0*q2);
    vy = 2 * (q0*q1 + q2*q3);
    vz = q0*q0 - q1*q1 - q2*q2 + q3*q3;

    // 计算加速度计测量值与重力向量的误差
    ex = (ay*vz - az*vy);
    ey = (az*vx - ax*vz);
    ez = (ax*vy - ay*vx);

    // 积分误差累积
    I_ex += ex * delta_T;
    I_ey += ey * delta_T;
    I_ez += ez * delta_T;

    // 使用PI控制器输出修正后的陀螺仪角速度
    gx += icm_kp * ex + icm_ki * I_ex;
    gy += icm_kp * ey + icm_ki * I_ey;
    gz += icm_kp * ez + icm_ki * I_ez;

    // 龙格-库塔法更新四元数
    q0 += (-q1*gx - q2*gy - q3*gz) * halfT;
    q1 += (q0*gx + q2*gz - q3*gy) * halfT;
    q2 += (q0*gy - q1*gz + q3*gx) * halfT;
    q3 += (q0*gz + q1*gy - q2*gx) * halfT;

    // 归一化四元数
    norm = normalize_quaternion(&Q_info);
    if (norm == 0) {

        return;
    }

    // 更新全局四元数
    Q_info.q0 = q0;
    Q_info.q1 = q1;
    Q_info.q2 = q2;
    Q_info.q3 = q3;

    // 计算欧拉角（单位：度）
    eulerAngle.pitch = asinf(2 * (q0*q2 - q1*q3)) * RAD_TO_DEG;
    eulerAngle.roll = atan2f(2 * (q2*q3 + q0*q1), 1 - 2 * (q1*q1 + q2*q2)) * RAD_TO_DEG;
    eulerAngle.yaw = atan2f(2 * (q1*q2 + q0*q3), 1 - 2 * (q2*q2 + q3*q3)) * RAD_TO_DEG;


}
