//----------------------------------Include------------------------------------
#include "my_type_rdf.h"
#include "my_mcu.h"
#include "my_board.h"
#include "my_glbvar.h"
//-----------------------------------------------------------------------------

//--------------------------------Public Func----------------------------------
void MyBrd_InitMcu(void)
{ 
//  MyMcu_Disable_Jtag();
//  MyMcu_Int_Disable();
//  
  MyMcu_SysClock();
//  MyMcu_PriGrpCfg();
//  
  MyMcu_Init_Tim21();
  MyMcu_Init_Tim2();
  MyMcu_Init_DO();
	Configure_DMA();
  MyMcu_Init_ADC();
	Activate_ADC();
	i2c_CheckDevice(SLAVE_VCNL36825T_Addr);
	INIT_VCNL36825T();
	MyMcu_Init_EXTI();
	
	
////	I2C1_Slave_Init();
 
//  MyMcu_Init_Wdt();
//  MyMcu_Int_Enable();
}


//------------------------------------EOF--------------------------------------

